import Foundation
import SwiftUI

@MainActor
@Observable
class DataStore {
    var recordings: [Recording] = []
    var collections: [RecordingCollection] = []
    var tags: [Tag] = []
    var searchText: String = ""
    var isDarkMode: Bool = true
    
    private let recordingsKey = "savedRecordings"
    private let collectionsKey = "savedCollections"
    private let tagsKey = "savedTags"
    private let darkModeKey = "isDarkMode"
    private var colorCounter: Int = 0
    
    init() {
        loadData()
    }
    
    // MARK: - Computed Properties
    
    var favorites: [Recording] {
        recordings.filter { $0.isFavorite }
    }
    
    var sortedRecordings: [Recording] {
        recordings.sorted { $0.date > $1.date }
    }
    
    var filteredRecordings: [Recording] {
        if searchText.isEmpty {
            return sortedRecordings
        }
        return sortedRecordings.filter {
            $0.title.localizedCaseInsensitiveContains(searchText)
        }
    }
    
    func recordings(for collectionId: UUID) -> [Recording] {
        recordings.filter { $0.collectionId == collectionId }
            .sorted { $0.date > $1.date }
    }
    
    func recordingCount(for collectionId: UUID) -> Int {
        recordings.filter { $0.collectionId == collectionId }.count
    }
    
    /// Returns true if any recording (other than `excludingId`) already uses `name` (case-insensitive).
    func titleExists(_ name: String, excludingId: UUID? = nil) -> Bool {
        recordings.contains {
            $0.title.localizedCaseInsensitiveCompare(name) == .orderedSame &&
            $0.id != excludingId
        }
    }
    
    // MARK: - Recording CRUD
    
    func addRecording(_ recording: Recording) {
        // Pick the first palette color NOT already used by the top-4 most-recent recordings.
        // This ensures all 5 visible orbital cards always have distinct colors.
        let paletteSize = Recording.cardColors.count          // 5
        let visibleColors = Set(
            sortedRecordings.prefix(4).map { $0.accentColorIndex % paletteSize }
        )
        let availableIndex = (0..<paletteSize).first { !visibleColors.contains($0) }
            ?? (colorCounter % paletteSize)   // fallback: round-robin

        var r = recording
        r.accentColorIndex = availableIndex
        colorCounter = (availableIndex + 1) % paletteSize

        recordings.append(r)
        // Bump the bucket's lastModifiedDate so it appears first
        if let cid = r.collectionId,
           let ci = collections.firstIndex(where: { $0.id == cid }) {
            collections[ci].lastModifiedDate = Date()
        }
        saveData()
    }
    
    func deleteRecording(_ recording: Recording) {
        // Delete audio file
        if let url = recording.audioURL {
            try? FileManager.default.removeItem(at: url)
        }
        // Bump the bucket's lastModifiedDate so it reflects the change
        if let cid = recording.collectionId,
           let ci = collections.firstIndex(where: { $0.id == cid }) {
            collections[ci].lastModifiedDate = Date()
        }
        recordings.removeAll { $0.id == recording.id }
        saveData()
    }
    
    func updateRecording(_ recording: Recording) {
        if let index = recordings.firstIndex(where: { $0.id == recording.id }) {
            recordings[index] = recording
            saveData()
        }
    }
    
    func toggleFavorite(_ recording: Recording) {
        if let index = recordings.firstIndex(where: { $0.id == recording.id }) {
            recordings[index].isFavorite.toggle()
            saveData()
        }
    }
    
    func assignToCollection(_ recording: Recording, collectionId: UUID?) {
        if let index = recordings.firstIndex(where: { $0.id == recording.id }) {
            recordings[index].collectionId = collectionId
            // Bump the bucket's lastModifiedDate so it appears first
            if let cid = collectionId,
               let ci = collections.firstIndex(where: { $0.id == cid }) {
                collections[ci].lastModifiedDate = Date()
            }
            saveData()
        }
    }
    
    func nextColorIndex() -> Int {
        let index = colorCounter
        colorCounter += 1
        return index
    }
    
    // MARK: - Collection CRUD
    
    func addCollection(_ collection: RecordingCollection) {
        collections.append(collection)
        saveData()
    }
    
    func renameCollection(_ collection: RecordingCollection, newName: String) {
        if let index = collections.firstIndex(where: { $0.id == collection.id }) {
            collections[index].name = newName
            collections[index].lastModifiedDate = Date()
            saveData()
        }
    }
    
    func updateCollection(_ collection: RecordingCollection) {
        if let index = collections.firstIndex(where: { $0.id == collection.id }) {
            var updated = collection
            updated.lastModifiedDate = Date()
            collections[index] = updated
            saveData()
        }
    }
    
    func deleteCollection(_ collection: RecordingCollection) {
        // Unassign recordings from this collection
        for i in recordings.indices {
            if recordings[i].collectionId == collection.id {
                recordings[i].collectionId = nil
            }
        }
        collections.removeAll { $0.id == collection.id }
        saveData()
    }
    
    // MARK: - Tag CRUD
    
    func addTag(_ tag: Tag) {
        tags.append(tag)
        saveData()
    }
    
    func deleteTag(_ tag: Tag) {
        tags.removeAll { $0.id == tag.id }
        saveData()
    }
    
    // MARK: - Persistence
    
    private func saveData() {
        if let encoded = try? JSONEncoder().encode(recordings) {
            UserDefaults.standard.set(encoded, forKey: recordingsKey)
        }
        if let encoded = try? JSONEncoder().encode(collections) {
            UserDefaults.standard.set(encoded, forKey: collectionsKey)
        }
        if let encoded = try? JSONEncoder().encode(tags) {
            UserDefaults.standard.set(encoded, forKey: tagsKey)
        }
    }
    
    private func loadData() {
        if let data = UserDefaults.standard.data(forKey: recordingsKey),
           let decoded = try? JSONDecoder().decode([Recording].self, from: data) {
            recordings = decoded
        }
        if let data = UserDefaults.standard.data(forKey: collectionsKey),
           let decoded = try? JSONDecoder().decode([RecordingCollection].self, from: data) {
            collections = decoded
        }
        if let data = UserDefaults.standard.data(forKey: tagsKey),
           let decoded = try? JSONDecoder().decode([Tag].self, from: data) {
            tags = decoded
        } else {
            // Seed default tags on first launch
            tags = Tag.defaultTags
        }
        colorCounter = recordings.count
    }
}
