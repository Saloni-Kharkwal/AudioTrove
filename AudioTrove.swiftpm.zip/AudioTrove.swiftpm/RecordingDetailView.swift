import SwiftUI
import AVFoundation

// MARK: - Recording Detail View

struct RecordingDetailView: View {
    @Environment(DataStore.self)    private var dataStore
    @Environment(AudioManager.self) private var audioManager
    @Environment(\.dismiss)         private var dismiss

    let recording: Recording

    @State private var showEditSheet        = false
    @State private var showDeleteConfirm    = false
    @State private var showRenameAlert      = false
    @State private var renameText           = ""
    @State private var showCollectionPicker = false
    @State private var editedNotes          = ""
    @State private var showShareSheet       = false

    var current: Recording {
        dataStore.recordings.first { $0.id == recording.id } ?? recording
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 12) {
                        // Title row with ··· menu
                        HStack(alignment: .top) {
                            Button {
                                renameText = current.title; showRenameAlert = true
                            } label: {
                                Text(current.title)
                                    .font(.title2.bold()).foregroundStyle(.primary)
                                    .multilineTextAlignment(.leading)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            .buttonStyle(.plain)

                            Menu {
                                Button {
                                    showShareSheet = true
                                } label: {
                                    Label("Share Recording", systemImage: "square.and.arrow.up")
                                }
                                Button {
                                    renameText = current.title; showRenameAlert = true
                                } label: {
                                    Label("Rename", systemImage: "pencil")
                                }
                                Button {
                                    dataStore.toggleFavorite(current)
                                } label: {
                                    Label(current.isFavorite ? "Remove Favorite" : "Add to Favorites",
                                          systemImage: current.isFavorite ? "star.slash" : "star")
                                }
                                Divider()
                                Button(role: .destructive) { showDeleteConfirm = true } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                            } label: {
                                Image(systemName: "ellipsis")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundStyle(.secondary)
                                    .padding(7).background(Color(.systemGray5), in: Circle())
                            }
                        }

                        Text("\(current.formattedDate)  \(current.formattedDuration)")
                            .font(.subheadline).foregroundStyle(.secondary)

                        PlaybackWaveformView(
                            samples: current.waveformSamples,
                            progress: audioManager.playbackProgress,
                            activeColor: .primary,
                            inactiveColor: Color(.systemGray4),
                            barWidth: 2, spacing: 1.4
                        ) { fraction in scrubTo(fraction) }
                        .frame(height: 48).padding(.top, 4)

                        HStack {
                            Text(formatTime(audioManager.currentTime))
                            Spacer()
                            Text("-\(formatTime(max(0, current.duration - audioManager.currentTime)))")
                        }
                        .font(.caption.monospacedDigit()).foregroundStyle(.secondary)

                        HStack(spacing: 0) {
                            Spacer()
                            tpButton("waveform")        { showEditSheet = true }
                            Spacer()
                            tpButton("gobackward.5")    { audioManager.skipBackward() }
                            Spacer()
                            Button { togglePlayback() } label: {
                                Image(systemName: audioManager.isPlaying ? "pause.fill" : "play.fill")
                                    .font(.system(size: 32, weight: .medium))
                                    .foregroundStyle(.primary).frame(width: 48, height: 48)
                            }.buttonStyle(.plain)
                            Spacer()
                            tpButton("goforward.5")     { audioManager.skipForward() }
                            Spacer()
                            tpButton("trash")           { showDeleteConfirm = true }
                            Spacer()
                        }
                        .padding(.vertical, 8)
                    }
                    .padding(.vertical, 8)
                }

                Section {
                    Button { showCollectionPicker = true } label: {
                        HStack(spacing: 14) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 8).fill(Color.purple.opacity(0.15)).frame(width: 32, height: 32)
                                Image(systemName: "folder").font(.system(size: 14)).foregroundStyle(.purple)
                            }
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Bucket").font(.body).foregroundStyle(.primary)
                                Text(bucketName).font(.subheadline).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.caption.weight(.semibold)).foregroundStyle(Color(.systemGray3))
                        }
                    }.buttonStyle(.plain)
                }

                if !current.tags.isEmpty {
                    Section("Tags") {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(current.tags, id: \.self) { tag in
                                    Text(tag).font(.caption.weight(.medium))
                                        .lineLimit(1)
                                        .padding(.horizontal, 10).padding(.vertical, 5)
                                        .background(Color(.systemGray6), in: Capsule())
                                        .foregroundStyle(.secondary)
                                        .fixedSize()
                                }
                            }
                        }
                    }
                }

                Section {
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Image(systemName: "text.alignleft").foregroundStyle(.blue)
                            Text("Notes / Lyrics").font(.body.weight(.medium)).foregroundStyle(.blue)
                            Spacer()
                        }
                        TextField("Add notes or lyrics…", text: $editedNotes, axis: .vertical)
                            .font(.body).lineLimit(5...12)
                            .onChange(of: editedNotes) { _, _ in saveNotes() }
                    }.padding(.vertical, 4)
                }
            }
            .listStyle(.insetGrouped)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading)  { Button("Done") { dismiss() } }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { dataStore.toggleFavorite(current) } label: {
                        Image(systemName: current.isFavorite ? "star.fill" : "star")
                            .foregroundStyle(current.isFavorite ? .yellow : .primary)
                    }
                }
            }
        }
        .onAppear {
            editedNotes = current.notes
            if let url = current.audioURL, !audioManager.isPlaying {
                audioManager.startPlayback(url: url); audioManager.pausePlayback()
            }
        }
        .onDisappear { audioManager.stopPlayback(); saveNotes() }
        .sheet(isPresented: $showEditSheet) {
            EditRecordingSheet(recording: current)
                .environment(dataStore).environment(audioManager)
                .presentationDetents([.large]).presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showCollectionPicker) {
            CollectionPickerSheet(recording: current).environment(dataStore)
        }
        .sheet(isPresented: $showShareSheet) {
            if let url = current.audioURL { ShareSheet(items: [url]) }
        }
        .confirmationDialog("Delete \"\(current.title)\"?", isPresented: $showDeleteConfirm, titleVisibility: .visible) {
            Button("Delete Recording", role: .destructive) {
                audioManager.stopPlayback(); dataStore.deleteRecording(current); dismiss()
            }
            Button("Cancel", role: .cancel) { }
        }
        .alert("Rename", isPresented: $showRenameAlert) {
            TextField("Name", text: $renameText)
                .onChange(of: renameText) { _, newValue in
                    if newValue.count > 25 {
                        renameText = String(newValue.prefix(25))
                    }
                }
            Button("Save") {
                let trimmed = renameText.trimmingCharacters(in: .whitespaces)
                guard !trimmed.isEmpty,
                      !dataStore.titleExists(trimmed, excludingId: current.id)
                else { return }
                var u = current; u.title = trimmed; dataStore.updateRecording(u)
            }
            Button("Cancel", role: .cancel) { }
        } message: {
            if dataStore.titleExists(renameText.trimmingCharacters(in: .whitespaces), excludingId: current.id) {
                Text("That name is already taken. Choose a different one.")
            }
        }
    }

    @ViewBuilder private func tpButton(_ sym: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: sym).font(.system(size: 24, weight: .light))
                .foregroundStyle(.primary).frame(width: 44, height: 44)
        }.buttonStyle(.plain)
    }

    private var bucketName: String {
        guard let id = current.collectionId else { return "None" }
        return dataStore.collections.first { $0.id == id }?.name ?? "None"
    }
    private func togglePlayback() {
        guard let url = current.audioURL else { return }
        if audioManager.isPlaying { audioManager.pausePlayback() }
        else { audioManager.startPlayback(url: url) }
    }
    private func scrubTo(_ f: Double) {
        guard let url = current.audioURL else { return }
        if !audioManager.isPlaying { audioManager.startPlayback(url: url); audioManager.pausePlayback() }
        audioManager.seek(to: current.duration * f)
    }
    private func saveNotes() {
        guard editedNotes != current.notes else { return }
        var u = current; u.notes = editedNotes; dataStore.updateRecording(u)
    }
    private func formatTime(_ t: TimeInterval) -> String {
        String(format: "%d:%02d", Int(t)/60, Int(t)%60)
    }
}

// MARK: - Edit Recording Sheet  (Voice Memos style)

struct EditRecordingSheet: View {
    @Environment(DataStore.self)    private var dataStore
    @Environment(AudioManager.self) private var audioManager
    @Environment(\.dismiss)         private var dismiss

    let recording: Recording

    @State private var isEditRecording = false
    @State private var editMode:       AudioManager.EditMode = .none
    @State private var isMerging       = false
    @State private var liveRecording:  Recording
    @State private var showTrimSheet   = false
    @State private var canUndo         = false

    init(recording: Recording) {
        self.recording = recording
        _liveRecording = State(initialValue: recording)
    }

    private var isAtEnd:     Bool   { audioManager.playbackProgress >= 0.999 }
    private var actionLabel: String { isEditRecording ? "Stop" : (isAtEnd ? "Resume" : "Replace") }
    private var actionColor: Color  {
        isEditRecording ? Color(red: 0.50, green: 0.06, blue: 0.06)
                        : Color(red: 0.98, green: 0.21, blue: 0.21)
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {

                // ── Title ────────────────────────────────────────────────
                VStack(spacing: 3) {
                    Text(liveRecording.title)
                        .font(.headline).multilineTextAlignment(.center)
                    Text("\(liveRecording.formattedDate)  \(liveRecording.formattedDuration)")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity).padding(.top, 8).padding(.bottom, 20)

                // ── Waveform (stretch-to-fill for guaranteed sync) ────────
                GeometryReader { geo in
                    let W = geo.size.width
                    let H = geo.size.height
                    let samples  = liveRecording.waveformSamples
                    let count    = max(1, samples.count)
                    let slotW    = W / CGFloat(count)        // width per bar slot
                    let barW     = slotW * 0.50              // bar = 50% of slot
                    let progress = audioManager.playbackProgress

                    ZStack(alignment: .leading) {
                        // Waveform bars
                        Canvas { ctx, size in
                            for (i, sample) in samples.enumerated() {
                                let slotX  = CGFloat(i) * slotW
                                let x      = slotX + (slotW - barW) / 2.0
                                let barH   = max(4.0, CGFloat(sample) * size.height * 0.82)
                                let rect   = CGRect(x: x, y: (size.height - barH) / 2.0,
                                                    width: barW, height: barH)
                                let frac   = Double(i) / Double(max(1, count - 1))
                                // passed = dark charcoal, upcoming = light gray
                                let shade  = frac <= progress ? 0.14 : 0.80
                                ctx.fill(Path(roundedRect: rect, cornerRadius: barW / 2.0),
                                         with: .color(Color(white: shade)))
                            }

                            // Live recording overlay (grows from recording start)
                            if isEditRecording {
                                let startFrac = audioManager.currentEditOffset
                                              / max(0.001, liveRecording.duration)
                                let startSlot = Int(startFrac * Double(count))
                                for (j, level) in audioManager.audioLevels.enumerated() {
                                    let idx = startSlot + j
                                    guard idx < count else { break }
                                    let slotX  = CGFloat(idx) * slotW
                                    let x      = slotX + (slotW - barW) / 2.0
                                    let barH   = max(4.0, CGFloat(level) * size.height * 0.82)
                                    let rect   = CGRect(x: x, y: (size.height - barH) / 2.0,
                                                        width: barW, height: barH)
                                    ctx.fill(Path(roundedRect: rect, cornerRadius: barW / 2.0),
                                             with: .color(Color(white: 0.14)))
                                }
                            }
                        }
                        .frame(width: W, height: H)

                        // Blue playhead — position maps 1:1 to audio progress
                        let phX: CGFloat = {
                            if isEditRecording {
                                let startFrac = audioManager.currentEditOffset
                                              / max(0.001, liveRecording.duration)
                                let elapsed   = audioManager.currentTime
                                              / max(0.001, liveRecording.duration)
                                return CGFloat(min(1.0, startFrac + elapsed)) * W
                            }
                            return CGFloat(progress) * W
                        }()

                        VStack(spacing: 0) {
                            Circle().fill(Color.blue).frame(width: 8, height: 8)
                            Rectangle().fill(Color.blue).frame(width: 1.5)
                            Circle().fill(Color.blue).frame(width: 8, height: 8)
                        }
                        .frame(height: H)
                        .offset(x: phX - 4)
                        .allowsHitTesting(false)
                    }
                    // Tap/drag to scrub
                    .contentShape(Rectangle())
                    .gesture(DragGesture(minimumDistance: 0).onChanged { val in
                        guard !isEditRecording else { return }
                        let frac = Double(max(0, min(val.location.x, W)) / W)
                        audioManager.seek(to: liveRecording.duration * frac)
                    })
                }
                .frame(height: 160)

                // Timeline labels
                HStack(spacing: 0) {
                    ForEach(0...4, id: \.self) { i in
                        let t = liveRecording.duration * Double(i) / 4.0
                        if i > 0 { Spacer(minLength: 0) }
                        Text(String(format: "%d:%02d", Int(t)/60, Int(t)%60))
                            .font(.system(size: 9, design: .monospaced))
                            .foregroundStyle(Color(.tertiaryLabel))
                    }
                }
                .padding(.horizontal, 6).padding(.top, 5).padding(.bottom, 2)

                // Large timer
                Text(formatTime(audioManager.currentTime))
                    .font(.system(size: 52, weight: .bold)).monospacedDigit().kerning(-1)
                    .padding(.vertical, 8)

                // Transport controls — Voice Memos style
                HStack(spacing: 52) {
                    Button {
                        guard !isEditRecording else { return }
                        audioManager.skipBackward(15)
                    } label: {
                        Image(systemName: "gobackward.15")
                            .font(.system(size: 28, weight: .light))
                            .foregroundStyle(isEditRecording ? Color(.quaternaryLabel) : .primary)
                    }.buttonStyle(.plain)

                    Button {
                        guard !isEditRecording else { return }
                        if audioManager.isPlaying {
                            audioManager.pausePlayback()
                        } else if let url = liveRecording.audioURL {
                            let atEnd = audioManager.playbackProgress >= 0.999
                            audioManager.startPlayback(url: url)
                            audioManager.seek(to: atEnd ? 0 : audioManager.currentTime)
                        }
                    } label: {
                        Image(systemName: audioManager.isPlaying ? "pause.fill" : "play.fill")
                            .font(.system(size: 32, weight: .medium))
                            .foregroundStyle(isEditRecording ? Color(.quaternaryLabel) : .primary)
                    }.buttonStyle(.plain)

                    Button {
                        guard !isEditRecording else { return }
                        audioManager.skipForward(15)
                    } label: {
                        Image(systemName: "goforward.15")
                            .font(.system(size: 28, weight: .light))
                            .foregroundStyle(isEditRecording ? Color(.quaternaryLabel) : .primary)
                    }.buttonStyle(.plain)
                }
                .padding(.bottom, 18)

                Divider()

                // Replace / Resume / Stop pill — centered, no side buttons
                Button { handleActionButton() } label: {
                    if isMerging {
                        HStack(spacing: 8) {
                            ProgressView().tint(.white).scaleEffect(0.8)
                            Text("Processing…").font(.subheadline.weight(.semibold)).lineLimit(1)
                        }
                        .foregroundStyle(.white)
                        .padding(.horizontal, 40).padding(.vertical, 14)
                        .background(Color(.systemGray2), in: Capsule())
                    } else {
                        HStack(spacing: 8) {
                            if isEditRecording {
                                Circle().fill(.white.opacity(0.85)).frame(width: 8, height: 8)
                            }
                            Text(actionLabel)
                                .font(.subheadline.weight(.bold)).lineLimit(1).fixedSize()
                        }
                        .foregroundStyle(.white)
                        .padding(.horizontal, 44).padding(.vertical, 15)
                        .background(actionColor, in: Capsule())
                    }
                }
                .buttonStyle(.plain).disabled(isMerging)
                .frame(maxWidth: .infinity).padding(.vertical, 18)
            }
            .background(Color(.systemBackground))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                // ··· menu — native iOS floating glass card
                ToolbarItem(placement: .navigationBarLeading) {
                    Menu {
                        if canUndo && !isEditRecording {
                            Button { undoReplace() } label: {
                                Label("Undo", systemImage: "arrow.uturn.backward")
                            }
                        }
                        if !isEditRecording {
                            Button {
                                audioManager.pausePlayback()
                                showTrimSheet = true
                            } label: {
                                Label("Trim", systemImage: "crop")
                            }
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle").font(.system(size: 17))
                    }
                    .disabled(isEditRecording)
                }

                // Done — native iOS floating glass save menu
                ToolbarItem(placement: .navigationBarTrailing) {
                    if isEditRecording {
                        Button {
                            stopAndMerge()
                        } label: {
                            ZStack {
                                Circle().fill(Color.blue).frame(width: 30, height: 30)
                                Image(systemName: "checkmark")
                                    .font(.system(size: 14, weight: .bold)).foregroundStyle(.white)
                            }
                        }.buttonStyle(.plain)
                    } else {
                        Menu {
                            Button {
                                audioManager.clearBackup(); dismiss()
                            } label: {
                                Label("Save Recording", systemImage: "square.and.arrow.down")
                            }
                            Button { saveAsNew() } label: {
                                Label("Save as New Recording", systemImage: "plus.square.on.square")
                            }
                        } label: {
                            Text("Done").fontWeight(.semibold)
                        }
                    }
                }
            }
        }
        .onAppear {
            if let url = liveRecording.audioURL {
                audioManager.startPlayback(url: url); audioManager.pausePlayback()
            }
        }
        .onDisappear {
            if isEditRecording { audioManager.stopRecording() }
            audioManager.stopPlayback()
        }
        .sheet(isPresented: $showTrimSheet) {
            TrimSheet(liveRecording: $liveRecording)
                .environment(dataStore).environment(audioManager)
        }
    }

    // MARK: - Actions

    private func handleActionButton() {
        if isEditRecording { stopAndMerge() }
        else if isAtEnd    { startResume()  }
        else               { startReplace() }
    }

    private func startReplace() {
        guard let url = liveRecording.audioURL else { return }
        audioManager.pausePlayback()
        let offset = audioManager.currentTime
        audioManager.startReplaceRecording(targetURL: url, at: offset)
        withAnimation { isEditRecording = true }
        editMode = .replace; canUndo = true
    }

    private func startResume() {
        guard let url = liveRecording.audioURL else { return }
        let offset = audioManager.currentTime
        audioManager.pausePlayback()
        audioManager.startAppendRecording(targetURL: url, at: offset)
        withAnimation { isEditRecording = true }
        editMode = .append; canUndo = true
    }

    private func stopAndMerge() {
        guard isEditRecording else { return }
        let (clipURL, _) = audioManager.stopRecording()
        guard let clipURL, let targetURL = audioManager.currentEditTargetURL else {
            withAnimation { isEditRecording = false }; return
        }
        let offset = audioManager.currentEditOffset
        let mode   = editMode
        isMerging  = true
        withAnimation { isEditRecording = false }

        Task { @MainActor in
            if let mergedURL = await audioManager.mergeAudio(
                original: targetURL, newClip: clipURL, mode: mode, offset: offset
            ) {
                var u = liveRecording
                u.audioFileName = mergedURL.lastPathComponent
                let asset = AVURLAsset(url: mergedURL)
                u.duration = (try? await asset.load(.duration))
                    .map { CMTimeGetSeconds($0) } ?? liveRecording.duration
                u.waveformSamples = Recording.generateRandomWaveform()
                dataStore.updateRecording(u); liveRecording = u
                if targetURL.lastPathComponent != u.audioFileName {
                    try? FileManager.default.removeItem(at: targetURL)
                }
                audioManager.startPlayback(url: mergedURL)
                audioManager.pausePlayback(); audioManager.seek(to: 0)
            }
            isMerging = false
        }
    }

    private func undoReplace() {
        guard let backupURL = audioManager.originalBackupURL else { return }
        audioManager.stopPlayback(); isMerging = true
        Task { @MainActor in
            let restoreURL = docs().appendingPathComponent("restored_\(UUID().uuidString).m4a")
            guard (try? FileManager.default.copyItem(at: backupURL, to: restoreURL)) != nil else {
                isMerging = false; return
            }
            if let old = liveRecording.audioURL { try? FileManager.default.removeItem(at: old) }
            var u             = liveRecording
            u.audioFileName   = restoreURL.lastPathComponent
            let asset         = AVURLAsset(url: restoreURL)
            u.duration        = (try? await asset.load(.duration))
                .map { CMTimeGetSeconds($0) } ?? liveRecording.duration
            u.waveformSamples = Recording.generateRandomWaveform()
            dataStore.updateRecording(u); liveRecording = u
            canUndo = false; audioManager.clearBackup(); editMode = .none
            audioManager.startPlayback(url: restoreURL)
            audioManager.pausePlayback(); audioManager.seek(to: 0)
            isMerging = false
        }
    }

    private func saveAsNew() {
        guard let url = liveRecording.audioURL else { audioManager.clearBackup(); dismiss(); return }
        let newURL = docs().appendingPathComponent("copy_\(UUID().uuidString).m4a")
        try? FileManager.default.copyItem(at: url, to: newURL)
        var r = liveRecording; r.id = UUID()
        r.audioFileName = newURL.lastPathComponent; r.title = liveRecording.title + " (Copy)"
        dataStore.addRecording(r); audioManager.clearBackup(); dismiss()
    }

    private func docs() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    private func formatTime(_ t: TimeInterval) -> String {
        let m  = Int(t)/60; let s = Int(t)%60
        let cs = Int(t.truncatingRemainder(dividingBy: 1) * 100)
        return String(format: "%02d:%02d.%02d", m, s, cs)
    }
}

// MARK: - Trim Sheet

struct TrimSheet: View {
    @Environment(DataStore.self)    private var dataStore
    @Environment(AudioManager.self) private var audioManager
    @Environment(\.dismiss)         private var dismiss

    @Binding var liveRecording: Recording

    @State private var trimStart:    Double = 0
    @State private var trimEnd:      Double = 1
    @State private var isProcessing: Bool   = false
    @State private var monitorTask:  Task<Void, Never>? = nil

    private var dur:          TimeInterval { liveRecording.duration }
    private var trimStartSec: TimeInterval { trimStart * dur }
    private var trimEndSec:   TimeInterval { trimEnd   * dur }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {

                // Title
                VStack(spacing: 3) {
                    Text(liveRecording.title).font(.headline).multilineTextAlignment(.center)
                    Text("\(liveRecording.formattedDate)  \(liveRecording.formattedDuration)")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity).padding(.top, 8).padding(.bottom, 12)

                // ── Main waveform (beige, yellow selection) ───────────────
                GeometryReader { geo in
                    let W = geo.size.width
                    let H = geo.size.height
                    let samples = liveRecording.waveformSamples
                    let count   = max(1, samples.count)
                    let slotW   = W / CGFloat(count)
                    let barW    = slotW * 0.50
                    let sX      = CGFloat(trimStart) * W
                    let eX      = CGFloat(trimEnd)   * W
                    let phX     = CGFloat(audioManager.playbackProgress) * W

                    ZStack(alignment: .leading) {
                        // Waveform bars
                        Canvas { ctx, size in
                            for (i, sample) in samples.enumerated() {
                                let slotX = CGFloat(i) * slotW
                                let x     = slotX + (slotW - barW) / 2.0
                                let barH  = max(4.0, CGFloat(sample) * size.height * 0.78)
                                let rect  = CGRect(x: x, y: (size.height - barH) / 2.0,
                                                   width: barW, height: barH)
                                let frac  = Double(i) / Double(max(1, count - 1))
                                let inside = frac >= trimStart && frac <= trimEnd
                                let shade: CGFloat = inside ? 0.20 : 0.80
                                ctx.fill(Path(roundedRect: rect, cornerRadius: barW / 2.0),
                                         with: .color(Color(white: shade)))
                            }
                        }
                        .frame(width: W, height: H)

                        // Dim outside selection
                        if sX > 0 {
                            Rectangle().fill(Color.black.opacity(0.16))
                                .frame(width: sX, height: H).allowsHitTesting(false)
                        }
                        if eX < W {
                            Rectangle().fill(Color.black.opacity(0.16))
                                .frame(width: W - eX, height: H).offset(x: eX)
                                .allowsHitTesting(false)
                        }

                        // Yellow top/bottom rails
                        let yellow = Color.blue
                        Rectangle().fill(yellow).frame(width: max(0, eX - sX), height: 4)
                            .offset(x: sX, y: -(H/2 - 2)).allowsHitTesting(false)
                        Rectangle().fill(yellow).frame(width: max(0, eX - sX), height: 4)
                            .offset(x: sX, y: H/2 - 2).allowsHitTesting(false)

                        // Left handle
                        ZStack {
                            Rectangle().fill(yellow).frame(width: 6, height: H)
                            RoundedRectangle(cornerRadius: 5).fill(yellow)
                                .frame(width: 20, height: 36)
                                .overlay(Image(systemName: "chevron.left")
                                    .font(.system(size: 10, weight: .bold)).foregroundColor(.black))
                        }
                        .offset(x: sX - 3)
                        .gesture(DragGesture().onChanged { v in
                            trimStart = max(0, min(trimEnd - 0.04, Double(v.location.x / W)))
                        })

                        // Right handle
                        ZStack {
                            Rectangle().fill(yellow).frame(width: 6, height: H)
                            RoundedRectangle(cornerRadius: 5).fill(yellow)
                                .frame(width: 20, height: 36)
                                .overlay(Image(systemName: "chevron.right")
                                    .font(.system(size: 10, weight: .bold)).foregroundColor(.black))
                        }
                        .offset(x: eX - 3)
                        .gesture(DragGesture().onChanged { v in
                            trimEnd = min(1, max(trimStart + 0.04, Double(v.location.x / W)))
                        })

                        // Blue playhead
                        VStack(spacing: 0) {
                            Circle().fill(Color.blue).frame(width: 8, height: 8)
                            Rectangle().fill(Color.blue).frame(width: 1.5)
                            Circle().fill(Color.blue).frame(width: 8, height: 8)
                        }
                        .frame(height: H).offset(x: phX - 4).allowsHitTesting(false)
                    }
                    .contentShape(Rectangle())
                    .gesture(DragGesture(minimumDistance: 4).onChanged { v in
                        let frac = Double(max(0, min(v.location.x, W)) / W)
                        audioManager.seek(to: dur * frac)
                    })
                }
                .frame(height: 200)
                .background(Color(red: 0.97, green: 0.95, blue: 0.88))

                // Timeline labels
                HStack(spacing: 0) {
                    ForEach(0...4, id: \.self) { i in
                        let t = dur * Double(i) / 4.0
                        if i > 0 { Spacer(minLength: 0) }
                        Text(String(format: "%d:%02d", Int(t)/60, Int(t)%60))
                            .font(.system(size: 9, design: .monospaced))
                            .foregroundStyle(Color(.tertiaryLabel))
                    }
                }.padding(.horizontal, 6).padding(.top, 4).padding(.bottom, 6)

                // Mini strip
                miniStrip.frame(height: 54).padding(.horizontal, 20).padding(.bottom, 8)

                // Timer
                Text(formatTime(audioManager.currentTime))
                    .font(.system(size: 48, weight: .bold)).monospacedDigit().kerning(-1)
                    .padding(.vertical, 4)

                // Transport — plays ONLY selected region
                HStack(spacing: 52) {
                    Button { audioManager.skipBackward(15) } label: {
                        Image(systemName: "gobackward.15").font(.system(size: 26, weight: .light))
                    }.buttonStyle(.plain)

                    Button { toggleTrimPlay() } label: {
                        Image(systemName: audioManager.isPlaying ? "pause.fill" : "play.fill")
                            .font(.system(size: 30, weight: .medium))
                    }.buttonStyle(.plain)

                    Button { audioManager.skipForward(15) } label: {
                        Image(systemName: "goforward.15").font(.system(size: 26, weight: .light))
                    }.buttonStyle(.plain)
                }
                .foregroundStyle(.primary).padding(.bottom, 16)

                Divider()

                // Trim + Delete buttons
                HStack(spacing: 12) {
                    Button { performTrim() } label: {
                        HStack(spacing: 6) {
                            Image(systemName: "scissors").font(.system(size: 14, weight: .medium))
                            Text("Trim").font(.system(size: 16, weight: .semibold))
                        }
                        .foregroundStyle(.primary).frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color(.systemGray5), in: RoundedRectangle(cornerRadius: 12))
                    }.buttonStyle(.plain).disabled(isProcessing)

                    Button { performDelete() } label: {
                        HStack(spacing: 6) {
                            Image(systemName: "trash").font(.system(size: 14, weight: .medium))
                            Text("Delete").font(.system(size: 16, weight: .semibold))
                        }
                        .foregroundStyle(.red).frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color(.systemGray5), in: RoundedRectangle(cornerRadius: 12))
                    }.buttonStyle(.plain).disabled(isProcessing)
                }
                .padding(.horizontal, 20).padding(.vertical, 14)
            }
            .background(Color(.systemBackground))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }.disabled(isProcessing)
                }
                ToolbarItem(placement: .principal) { Text("Trim").font(.headline) }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Apply") { performTrim() }.disabled(isProcessing)
                }
            }
        }
        .onAppear {
            if let url = liveRecording.audioURL {
                audioManager.startPlayback(url: url)
                audioManager.pausePlayback()
                audioManager.seek(to: trimStartSec)
            }
        }
        .onDisappear { monitorTask?.cancel(); audioManager.pausePlayback() }
        .overlay {
            if isProcessing {
                ZStack {
                    Color.black.opacity(0.35).ignoresSafeArea()
                    VStack(spacing: 12) {
                        ProgressView().scaleEffect(1.4).tint(.white)
                        Text("Processing…").foregroundStyle(.white).font(.subheadline.weight(.medium))
                    }
                    .padding(24).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                }
            }
        }
    }

    // MARK: - Trim play (selected region only)

    private func toggleTrimPlay() {
        if audioManager.isPlaying {
            monitorTask?.cancel()
            audioManager.pausePlayback()
        } else {
            guard let url = liveRecording.audioURL else { return }
            audioManager.startPlayback(url: url)
            audioManager.seek(to: trimStartSec)
            startRegionMonitor()
        }
    }

    private func startRegionMonitor() {
        monitorTask?.cancel()
        monitorTask = Task { @MainActor in
            while !Task.isCancelled {
                if audioManager.currentTime >= trimEndSec {
                    audioManager.pausePlayback()
                    audioManager.seek(to: trimStartSec)
                    break
                }
                try? await Task.sleep(nanoseconds: 50_000_000) // 50 ms poll
            }
        }
    }

    // MARK: - Mini strip

    private var miniStrip: some View {
        GeometryReader { geo in
            let W  = geo.size.width
            let H  = geo.size.height
            let sX = CGFloat(trimStart) * W
            let eX = CGFloat(trimEnd)   * W

            ZStack(alignment: .leading) {
                Canvas { ctx, size in
                    let samples = liveRecording.waveformSamples
                    let count   = max(1, samples.count)
                    let slotW   = size.width / CGFloat(count)
                    let bW      = slotW * 0.55
                    for (i, sample) in samples.enumerated() {
                        let x    = CGFloat(i) * slotW + (slotW - bW) / 2.0
                        let barH = max(2.0, CGFloat(sample) * size.height * 0.82)
                        let rect = CGRect(x: x, y: (size.height - barH)/2.0, width: bW, height: barH)
                        let frac = Double(i) / Double(max(1, count - 1))
                        let inside = frac >= trimStart && frac <= trimEnd
                        ctx.fill(Path(roundedRect: rect, cornerRadius: bW/2.0),
                                 with: .color(Color(white: inside ? 0.25 : 0.75)))
                    }
                }
                .frame(width: W, height: H)

                Rectangle()
                    .fill(Color.blue.opacity(0.18))
                    .frame(width: max(0, eX - sX), height: H).offset(x: sX)
                    .allowsHitTesting(false)
                Rectangle()
                    .stroke(Color.blue, lineWidth: 2.5)
                    .frame(width: max(0, eX - sX), height: H).offset(x: sX)
                    .allowsHitTesting(false)

                // Left handle
                ZStack {
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.blue).frame(width: 22, height: H)
                    Image(systemName: "chevron.left")
                        .font(.system(size: 9, weight: .bold)).foregroundColor(.black)
                }
                .offset(x: sX - 11)
                .gesture(DragGesture().onChanged { v in
                    trimStart = max(0, min(trimEnd - 0.04, Double(v.location.x / W)))
                })

                // Right handle
                ZStack {
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.blue).frame(width: 22, height: H)
                    Image(systemName: "chevron.right")
                        .font(.system(size: 9, weight: .bold)).foregroundColor(.black)
                }
                .offset(x: eX - 11)
                .gesture(DragGesture().onChanged { v in
                    trimEnd = min(1, max(trimStart + 0.04, Double(v.location.x / W)))
                })

                Rectangle().fill(Color.blue).frame(width: 2, height: H)
                    .offset(x: CGFloat(audioManager.playbackProgress) * W - 1)
                    .allowsHitTesting(false)
            }
            .clipShape(RoundedRectangle(cornerRadius: 8))
        }
    }

    // MARK: - Operations

    private func performTrim() {
        guard let url = liveRecording.audioURL else { return }
        audioManager.stopPlayback(); isProcessing = true
        Task { @MainActor in
            if let out = await audioManager.trimAudio(url: url, startTime: trimStartSec, endTime: trimEndSec) {
                await applyUpdate(newURL: out, oldURL: url)
            }
            isProcessing = false; dismiss()
        }
    }

    private func performDelete() {
        guard let url = liveRecording.audioURL else { return }
        audioManager.stopPlayback(); isProcessing = true
        Task { @MainActor in
            if let out = await audioManager.cutAudio(url: url, cutFrom: trimStartSec, to: trimEndSec) {
                await applyUpdate(newURL: out, oldURL: url)
            }
            isProcessing = false; dismiss()
        }
    }

    @MainActor
    private func applyUpdate(newURL: URL, oldURL: URL) async {
        if oldURL != newURL { try? FileManager.default.removeItem(at: oldURL) }
        var u             = liveRecording
        u.audioFileName   = newURL.lastPathComponent
        let asset         = AVURLAsset(url: newURL)
        u.duration        = (try? await asset.load(.duration))
            .map { CMTimeGetSeconds($0) } ?? liveRecording.duration
        u.waveformSamples = Recording.generateRandomWaveform()
        dataStore.updateRecording(u); liveRecording = u
    }

    private func formatTime(_ t: TimeInterval) -> String {
        let m = Int(t)/60; let s = Int(t)%60
        let cs = Int(t.truncatingRemainder(dividingBy: 1) * 100)
        return String(format: "%02d:%02d.%02d", m, s, cs)
    }
}

// MARK: - Collection Picker Sheet

struct CollectionPickerSheet: View {
    @Environment(DataStore.self) private var dataStore
    @Environment(\.dismiss)      private var dismiss
    let recording: Recording

    var body: some View {
        NavigationStack {
            List {
                Button {
                    dataStore.assignToCollection(recording, collectionId: nil); dismiss()
                } label: {
                    HStack {
                        Text("None").foregroundStyle(.primary); Spacer()
                        if recording.collectionId == nil { Image(systemName: "checkmark").foregroundStyle(.blue) }
                    }
                }.buttonStyle(.plain)

                ForEach(dataStore.collections) { col in
                    Button {
                        dataStore.assignToCollection(recording, collectionId: col.id); dismiss()
                    } label: {
                        HStack {
                            Image(systemName: col.iconName).foregroundStyle(.blue)
                            Text(col.name).foregroundStyle(.primary); Spacer()
                            if recording.collectionId == col.id {
                                Image(systemName: "checkmark").foregroundStyle(.blue)
                            }
                        }
                    }.buttonStyle(.plain)
                }
            }
            .navigationTitle("Add to Bucket").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
            }
        }
    }
}
