import SwiftUI

// MARK: - Mini Recording Sheet
// Presented as a sheet with .presentationDetents([.height(300)])
// Auto-saves on Stop. Pause/Stop only — no checkmark.

struct RecordingModalView: View {
    @Environment(AudioManager.self) private var audioManager
    @Environment(\.dismiss)         private var dismiss

    /// Called after auto-save so the card can animate in
    let onRecordingComplete: (URL, TimeInterval) -> Void

    @State private var pulse      = false
    @State private var showCancel = false
    @State private var showMicDeniedAlert = false

    var body: some View {
        VStack(spacing: 0) {

            // ── Drag handle
            Capsule()
                .fill(Color(.systemGray4))
                .frame(width: 36, height: 5)
                .padding(.top, 10)

            // ── Status row
            HStack {
                // Pulsing indicator
                HStack(spacing: 7) {
                    Circle()
                        .fill(Color.red)
                        .frame(width: 8, height: 8)
                        .opacity(audioManager.isPaused ? 0.35 : 1)
                        .scaleEffect(pulse && !audioManager.isPaused ? 1.25 : 1)
                        .animation(.easeInOut(duration: 0.75).repeatForever(autoreverses: true),
                                   value: pulse)
                    Text(audioManager.isPaused ? "Paused" : "Recording")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(audioManager.isPaused
                            ? AnyShapeStyle(.secondary)
                            : AnyShapeStyle(Color.red))
                }

                Spacer()

                // Timer
                Text(formattedTime(audioManager.currentTime))
                    .font(.system(size: 15, weight: .medium, design: .monospaced))
                    .foregroundStyle(.primary)
                    .animation(.linear(duration: 0.05), value: audioManager.currentTime)
                    .monospacedDigit()

                Spacer()

                // Cancel
                Button("Cancel") { showCancel = true }
                    .font(.system(size: 14))
                    .foregroundStyle(Color.blue)
            }
            .padding(.horizontal, 22)
            .padding(.top, 18)

            // ── Live waveform
            LiveWaveformView(levels: audioManager.audioLevels, color: Color.red.opacity(0.65))
                .frame(height: 48)
                .padding(.horizontal, 24)
                .padding(.top, 20)

            Spacer(minLength: 20)

            // ── Controls: Pause | Stop
            HStack(spacing: 0) {
                Spacer()

                // Pause / Resume
                Button {
                    if audioManager.isPaused { audioManager.resumeRecording() }
                    else { audioManager.pauseRecording() }
                } label: {
                    ZStack {
                        Circle()
                            .fill(Color(.systemGray5))
                            .frame(width: 58, height: 58)
                        Image(systemName: audioManager.isPaused ? "play.fill" : "pause.fill")
                            .font(.system(size: 22, weight: .medium))
                            .foregroundStyle(.primary)
                    }
                }
                .buttonStyle(.plain)

                Spacer()

                // Stop → pass to parent for saving
                Button { stopAndComplete() } label: {
                    ZStack {
                        Circle()
                            .fill(Color(.systemGray5))
                            .frame(width: 58, height: 58)
                        RoundedRectangle(cornerRadius: 7)
                            .fill(Color.red)
                            .frame(width: 24, height: 24)
                    }
                }
                .buttonStyle(.plain)

                Spacer()
            }
            .padding(.bottom, 36)
        }
        .background(Color(.systemBackground))
        .onAppear {
            pulse = true
            requestAndStart()
        }
        .onDisappear {
            // Safety: ensure recording is stopped if sheet dismissed externally
            _ = audioManager.stopRecording()
        }
        .confirmationDialog("Discard recording?", isPresented: $showCancel) {
            Button("Discard", role: .destructive) {
                let (url, _) = audioManager.stopRecording()
                if let url { try? FileManager.default.removeItem(at: url) }
                dismiss()
            }
            Button("Cancel", role: .cancel) { }
        }
        .alert("Microphone Access Required", isPresented: $showMicDeniedAlert) {
            Button("OK") { dismiss() }
        } message: {
            Text("Please enable microphone access in Settings › Recordings.")
        }
    }

    // MARK: - Helpers

    private func requestAndStart() {
        switch audioManager.currentMicPermission() {
        case .granted:
            audioManager.startRecording()
        case .denied:
            showMicDeniedAlert = true
        default:
            audioManager.requestMicrophonePermission { granted in
                Task { @MainActor in
                    if granted { self.audioManager.startRecording() }
                    else       { self.showMicDeniedAlert = true }
                }
            }
        }
    }

    private func stopAndComplete() {
        let (url, duration) = audioManager.stopRecording()
        guard let url else { dismiss(); return }
        onRecordingComplete(url, duration)
        dismiss()
    }

    private func formattedTime(_ t: TimeInterval) -> String {
        let m  = Int(t) / 60
        let s  = Int(t) % 60
        let cs = Int(t.truncatingRemainder(dividingBy: 1) * 100)
        return String(format: "%02d:%02d.%02d", m, s, cs)
    }
}
