import SwiftUI
import PhotosUI

// MARK: - LibraryView

struct LibraryView: View {
    @Environment(DataStore.self) private var dataStore
    @Binding var selectedRecording: Recording?
    @Binding var showSearch: Bool

    @State private var selectedTab: LibraryTab = .allRecordings
    @State private var showNewCollectionAlert   = false
    @State private var newCollectionName        = ""
    @State private var selectedCollection: RecordingCollection?
    @State private var showRenameAlert          = false
    @State private var renameText               = ""
    @State private var collectionToRename: RecordingCollection?
    @State private var recordingToDelete: Recording?
    @State private var showDeleteConfirm        = false
    @State private var selectedTag: String?

    enum LibraryTab: String, CaseIterable {
        case allRecordings = "Recordings"
        case buckets       = "Buckets"
        case tags          = "Tags"
    }

    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: 20) {

                // Header
                HStack {
                    Text("Library").font(.system(size: 34, weight: .bold))
                    Spacer()
                    if selectedTab == .buckets {
                        Button { showNewCollectionAlert = true } label: {
                            Image(systemName: "plus").font(.system(size: 18, weight: .medium))
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.top, 8)
                .padding(.bottom, 0)

                // Segmented Picker
                Picker("", selection: $selectedTab) {
                    ForEach(LibraryTab.allCases, id: \.self) { tab in
                        Text(tab.rawValue).tag(tab)
                    }
                }
                .pickerStyle(.segmented).padding(.horizontal)

                // Dynamic section heading
                Text(selectedTab.rawValue)
                    .font(.system(size: 20, weight: .bold))
                    .padding(.horizontal)
                    .padding(.top, 8)
                    .padding(.bottom, 2)
                    .animation(.none, value: selectedTab)

                // Content
                switch selectedTab {
                case .allRecordings: allRecordingsSection
                case .buckets:       bucketsSection
                case .tags:          tagsSection
                }

                Spacer(minLength: 40)
            }
        }
        .sheet(item: $selectedCollection) { col in
            CollectionDetailView(collection: col, selectedRecording: $selectedRecording)
                .environment(dataStore)
        }
        .sheet(item: $selectedTag) { tag in
            TagRecordingsView(tag: tag, selectedRecording: $selectedRecording)
                .environment(dataStore)
                .environment(AudioManager())
        }
        .confirmationDialog(
            "Delete \"\(recordingToDelete?.title ?? "")\"?",
            isPresented: $showDeleteConfirm,
            titleVisibility: .visible
        ) {
            Button("Delete Recording", role: .destructive) {
                if let r = recordingToDelete { dataStore.deleteRecording(r) }
                recordingToDelete = nil
            }
            Button("Cancel", role: .cancel) { recordingToDelete = nil }
        }
        .alert("New Bucket", isPresented: $showNewCollectionAlert) {
            TextField("Bucket Name", text: $newCollectionName)
            Button("Create") {
                if !newCollectionName.isEmpty {
                    let col = RecordingCollection(
                        name: newCollectionName,
                        iconName: "folder.fill",
                        colorIndex: dataStore.collections.count
                    )
                    dataStore.addCollection(col)
                    newCollectionName = ""
                }
            }
            Button("Cancel", role: .cancel) { newCollectionName = "" }
        }
        .alert("Rename Bucket", isPresented: $showRenameAlert) {
            TextField("Name", text: $renameText)
            Button("Rename") {
                if let col = collectionToRename, !renameText.isEmpty {
                    dataStore.renameCollection(col, newName: renameText)
                }
                collectionToRename = nil; renameText = ""
            }
            Button("Cancel", role: .cancel) { collectionToRename = nil; renameText = "" }
        }
    }

    // MARK: - All Recordings Tab (plain list, swipe-delete)

    @ViewBuilder
    private var allRecordingsSection: some View {
        let all = dataStore.sortedRecordings
        if all.isEmpty {
            emptyMessage("No recordings yet", icon: "mic.slash")
        } else {
            LazyVStack(spacing: 12) {
                ForEach(all) { rec in
                    recordingRow(rec)
                }
            }
            .padding(.horizontal)
        }
    }

    @ViewBuilder
    private func recordingRow(_ recording: Recording) -> some View {
        Button { selectedRecording = recording } label: {
            LibraryRecordingRow(recording: recording)
        }
        .buttonStyle(.plain)
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button(role: .destructive) {
                recordingToDelete = recording
                showDeleteConfirm  = true
            } label: {
                Label("Delete", systemImage: "trash")
            }
        }
    }

    // MARK: - Buckets Tab

    @ViewBuilder
    private var bucketsSection: some View {
        VStack(alignment: .leading, spacing: 16) {

            if dataStore.collections.isEmpty {
                emptyMessage("No buckets yet\nTap + to create one", icon: "folder")
            } else {
                let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]
                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(dataStore.collections) { col in
                        Button { selectedCollection = col } label: {
                            BucketCardView(collection: col,
                                           recordingCount: dataStore.recordingCount(for: col.id))
                        }
                        .buttonStyle(.plain)
                        .contextMenu {
                            Button {
                                collectionToRename = col; renameText = col.name; showRenameAlert = true
                            } label: { Label("Rename", systemImage: "pencil") }
                            Button(role: .destructive) { dataStore.deleteCollection(col) } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                }
                .padding(.horizontal)
            }
        }
    }

    // MARK: - Tags Tab (All Tags chips grid)

    @ViewBuilder
    private var tagsSection: some View {
        let allTags = Array(Set(dataStore.sortedRecordings.flatMap { $0.tags })).sorted()

        VStack(alignment: .leading, spacing: 16) {

            if allTags.isEmpty {
                emptyMessage("No tags yet\nAdd tags when saving a recording", icon: "tag.slash")
            } else {
                // Chip flow grid
                LazyVStack(alignment: .leading, spacing: 0) {
                    FlowTagsGrid(tags: allTags) { tag in
                        selectedTag = tag
                    }
                }
                .padding(.horizontal)
            }
        }
    }

    // MARK: - Empty State

    @ViewBuilder
    private func emptyMessage(_ text: String, icon: String) -> some View {
        VStack(spacing: 14) {
            Image(systemName: icon).font(.system(size: 36)).foregroundStyle(.secondary)
            Text(text).font(.system(size: 15)).foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity).padding(.top, 60)
    }
}

// MARK: - Flow Tags Grid

private struct FlowTagsGrid: View {
    let tags: [String]
    let onTap: (String) -> Void

    var body: some View {
        // Wrap chips in a flow layout using a simple VStack of HStacks
        WrapLayout(tags: tags, onTap: onTap)
    }
}

private struct WrapLayout: View {
    let tags: [String]
    let onTap: (String) -> Void

    var body: some View {
        FlowLayout(spacing: 10) {
            ForEach(tags, id: \.self) { tag in
                tagChip(tag)
            }
        }
    }

    @ViewBuilder
    private func tagChip(_ tag: String) -> some View {
        Button { onTap(tag) } label: {
            HStack(spacing: 5) {
                Image(systemName: tagIcon(for: tag))
                    .font(.system(size: 11, weight: .semibold))
                Text(tag)
                    .font(.system(size: 13, weight: .medium))
                    .fixedSize(horizontal: true, vertical: false)
                    .layoutPriority(1)
            }
            .fixedSize(horizontal: true, vertical: false)
            .foregroundStyle(tagColor(for: tag))
            .padding(.horizontal, 13)
            .padding(.vertical, 8)
            .background(
                Capsule().fill(tagColor(for: tag).opacity(0.13))
            )
        }
        .buttonStyle(.plain)
    }

    private func tagColor(for tag: String) -> Color {
        let palette: [Color] = [
            .blue, .purple, .pink, .orange, .green,
            .teal, .indigo, .red, .cyan, .yellow
        ]
        let idx = abs(tag.hashValue) % palette.count
        return palette[idx]
    }

    private func tagIcon(for tag: String) -> String {
        let lower = tag.lowercased()
        if lower.contains("music") || lower.contains("melody") || lower.contains("song") { return "music.note" }
        if lower.contains("lecture") || lower.contains("class") || lower.contains("study") { return "book.closed" }
        if lower.contains("idea") || lower.contains("brain") || lower.contains("thought") { return "lightbulb" }
        if lower.contains("important") || lower.contains("urgent") { return "exclamationmark.circle" }
        if lower.contains("daily") || lower.contains("recap") || lower.contains("log") { return "calendar" }
        if lower.contains("meeting") || lower.contains("call") { return "person.2" }
        if lower.contains("note") || lower.contains("memo") { return "note.text" }
        if lower.contains("voice") || lower.contains("record") { return "mic" }
        return "tag"
    }
}

// MARK: - Flow Layout (wrapping chip layout)

private struct FlowLayout: Layout {
    var spacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let width = proposal.width ?? .infinity
        var currentX: CGFloat = 0
        var currentY: CGFloat = 0
        var lineHeight: CGFloat = 0
        var totalHeight: CGFloat = 0

        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)
            if currentX + size.width > width, currentX > 0 {
                currentY += lineHeight + spacing
                totalHeight = currentY
                currentX = 0
                lineHeight = 0
            }
            currentX += size.width + spacing
            lineHeight = max(lineHeight, size.height)
        }
        totalHeight += lineHeight
        return CGSize(width: width, height: totalHeight)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var currentX: CGFloat = bounds.minX
        var currentY: CGFloat = bounds.minY
        var lineHeight: CGFloat = 0

        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)
            if currentX + size.width > bounds.maxX, currentX > bounds.minX {
                currentY += lineHeight + spacing
                currentX = bounds.minX
                lineHeight = 0
            }
            subview.place(at: CGPoint(x: currentX, y: currentY), proposal: ProposedViewSize(size))
            currentX += size.width + spacing
            lineHeight = max(lineHeight, size.height)
        }
    }
}

// MARK: - Library Recording Row

struct LibraryRecordingRow: View {
    @Environment(DataStore.self) private var dataStore
    let recording: Recording

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text(recording.title)
                    .font(.system(size: 15, weight: .semibold)).foregroundStyle(.primary).lineLimit(1)
                HStack(spacing: 6) {
                    Text(recording.formattedDate)
                    Text("·")
                    Text(recording.formattedDuration)
                }
                .font(.system(size: 12)).foregroundStyle(.secondary)
            }
            .frame(minWidth: 0)

            Spacer(minLength: 8)

            WaveformView(
                samples: Array(recording.waveformSamples.prefix(16)),
                color: recording.accentColor.opacity(0.75),
                barWidth: 2.5, spacing: 2
            )
            .frame(width: 64, height: 28)

            Button { dataStore.toggleFavorite(recording) } label: {
                Image(systemName: recording.isFavorite ? "star.fill" : "star")
                    .font(.system(size: 15))
                    .foregroundStyle(recording.isFavorite ? .yellow : Color(.systemGray3))
                    .frame(width: 36, height: 36)
            }.buttonStyle(.plain)

            Image(systemName: "chevron.right")
                .font(.system(size: 12, weight: .medium)).foregroundStyle(Color(.systemGray3))
        }
        .padding(.horizontal, 16).padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(Color(.systemBackground))
                .shadow(color: .black.opacity(0.05), radius: 6, y: 2)
        )
    }
}

// MARK: - String: Identifiable (for sheet(item:))
extension String: @retroactive Identifiable {
    public var id: String { self }
}
