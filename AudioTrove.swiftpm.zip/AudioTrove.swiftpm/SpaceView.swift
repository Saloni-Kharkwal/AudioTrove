import SwiftUI

// MARK: - Card Slot

private struct CardSlot {
    let xOffset: CGFloat
    let yOffset: CGFloat
    let width: CGFloat
    let height: CGFloat
    let rotation: Double
}

// MARK: - Arrangements
// Slot 0 = newest → directly above mic (center, y slightly up).
// Remaining slots alternate left/right.

private let cardArrangements: [[CardSlot]] = [
    // 1 card
    [CardSlot(xOffset: 0.00, yOffset: -0.28, width: 198, height: 148, rotation:  0)],
    // 2 cards
    [
        CardSlot(xOffset:  0.00, yOffset: -0.28, width: 198, height: 148, rotation:  0),
        CardSlot(xOffset: -0.54, yOffset:  0.34, width: 172, height: 128, rotation: -2),
    ],
    // 3 cards
    [
        CardSlot(xOffset:  0.00, yOffset: -0.28, width: 198, height: 148, rotation:  0),
        CardSlot(xOffset: -0.52, yOffset:  0.32, width: 174, height: 130, rotation: -2),
        CardSlot(xOffset:  0.52, yOffset:  0.32, width: 166, height: 124, rotation:  2),
    ],
    // 4 cards
    [
        CardSlot(xOffset:  0.00, yOffset: -0.28, width: 198, height: 148, rotation:  0),
        CardSlot(xOffset: -0.52, yOffset:  0.32, width: 174, height: 130, rotation: -2),
        CardSlot(xOffset:  0.52, yOffset:  0.32, width: 166, height: 124, rotation:  2),
        CardSlot(xOffset: -0.52, yOffset: -0.52, width: 160, height: 118, rotation: -3),
    ],
    // 5 cards
    [
        CardSlot(xOffset:  0.00, yOffset: -0.28, width: 198, height: 148, rotation:  0),
        CardSlot(xOffset: -0.52, yOffset:  0.32, width: 172, height: 128, rotation: -2),
        CardSlot(xOffset:  0.52, yOffset:  0.32, width: 162, height: 120, rotation:  2),
        CardSlot(xOffset: -0.52, yOffset: -0.52, width: 158, height: 116, rotation: -3),
        CardSlot(xOffset:  0.52, yOffset: -0.52, width: 152, height: 112, rotation:  2.5),
    ],
]

// MARK: - SpaceView

struct SpaceView: View {
    @Environment(DataStore.self) private var dataStore
    @Environment(AudioManager.self) private var audioManager
    @Binding var showRecordSheet: Bool
    @Binding var selectedRecording: Recording?
    @Binding var searchText: String
    @Binding var showSearch: Bool

    @State private var animatedIDs: Set<UUID> = []
    @State private var selectedCollection: RecordingCollection?
    @FocusState private var searchFocused: Bool

    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                // Title + App logo
                HStack {
                    Text("Space")
                        .font(.largeTitle.bold())
                    Spacer()
                    Image("AppIcon")
                        .resizable().scaledToFill()
                        .frame(width: 36, height: 36)
                        .clipShape(Circle())
                        .shadow(color: .black.opacity(0.12), radius: 4, y: 2)
                }
                .padding(.horizontal).padding(.top, 8).padding(.bottom, 4)

                // Search field — only when active
                if showSearch {
                    HStack(spacing: 8) {
                        Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                        TextField("Search recordings…", text: $searchText)
                            .font(.body).focused($searchFocused)
                        if !searchText.isEmpty {
                            Button { searchText = "" } label: {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundStyle(Color(.systemGray3))
                            }
                        }
                    }
                    .padding(10)
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color(.systemGray6)))
                    .padding(.horizontal).padding(.bottom, 4)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .onAppear { searchFocused = true }
                }

                // Section label
                Text("Recent Recordings")
                    .font(.headline).foregroundStyle(.primary)
                    .padding(.horizontal).padding(.top, 18).padding(.bottom, -6)

                orbitalCardsSection

                // Recent Buckets (tightly below orbital)
                bucketsSection
                    .padding(.top, 4)

                // Favorites
                favoritesSection
                    .padding(.top, 2)
                    .padding(.bottom, 20)
            }
        }
        .sheet(item: $selectedCollection) { col in
            CollectionDetailView(collection: col, selectedRecording: $selectedRecording)
                .environment(dataStore)
        }
    }

    // MARK: - Orbital Canvas

    @ViewBuilder
    private var orbitalCardsSection: some View {
        let recordings = Array(filteredRecordings.prefix(5))
        let count = recordings.count
        let arrangementIndex = max(0, min(count, 5) - 1)
        let slots = count > 0 ? cardArrangements[arrangementIndex] : []

        GeometryReader { geo in
            let cx = geo.size.width  / 2
            let cy = geo.size.height * 0.56   // shifted down — closes bottom gap
            let rx = geo.size.width  * 0.5
            let ry = geo.size.height * 0.5

            ZStack {
                // Cards — newest on top
                ForEach(Array(recordings.enumerated().reversed()), id: \.element.id) { index, recording in
                    if index < slots.count {
                        let slot    = slots[index]
                        let settled = animatedIDs.contains(recording.id)

                        Button {
                            selectedRecording = recording
                        } label: {
                            FloatingCardView(recording: recording, width: slot.width, height: slot.height)
                        }
                        .buttonStyle(.plain)
                        .rotationEffect(.degrees(settled ? slot.rotation : 0))
                        .scaleEffect(settled ? 1.0 : 0.4)
                        .opacity(settled ? 1.0 : 0.0)
                        .position(
                            x: settled ? cx + slot.xOffset * rx : cx,
                            y: settled ? cy + slot.yOffset * ry : cy
                        )
                        .zIndex(Double(slots.count - index))
                    }
                }

                // Mic button — always on top
                Button { showRecordSheet = true } label: {
                    ZStack {
                        // Outer glow
                        Circle()
                            .fill(RadialGradient(
                                colors: [.red.opacity(0.16), .red.opacity(0.06), .clear],
                                center: .center, startRadius: 44, endRadius: 96
                            ))
                            .frame(width: 192, height: 192)

                        // Soft halo
                        Circle()
                            .fill(.white.opacity(0.7))
                            .frame(width: 112, height: 112)
                            .blur(radius: 1.5)

                        // Red disc
                        Circle()
                            .fill(.red)
                            .frame(width: 94, height: 94)
                            .shadow(color: .red.opacity(0.38), radius: 22, y: 6)

                        Image(systemName: "mic.fill")
                            .font(.system(size: 36, weight: .medium))
                            .foregroundStyle(.white)
                    }
                }
                .position(x: cx, y: cy)
                .zIndex(100)

                // "Tap to record" label below mic
                Text("Tap to record")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(.secondary)
                    .position(x: cx, y: cy + 70)
                    .zIndex(101)
                    .allowsHitTesting(false)

            }
        }
        .frame(height: 380)
        .padding(.horizontal, 10)
        .onAppear { animateAll(recordings) }
        .onChange(of: recordings.map(\.id)) { oldIDs, newIDs in
            let added = Set(newIDs).subtracting(Set(oldIDs))
            guard !added.isEmpty else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                withAnimation(.easeOut(duration: 0.5)) {
                    for id in added { animatedIDs.insert(id) }
                }
            }
        }
    }

    private func animateAll(_ recordings: [Recording]) {
        withAnimation(.easeOut(duration: 0.55)) {
            for r in recordings { animatedIDs.insert(r.id) }
        }
    }

    // MARK: - Buckets Section

    @ViewBuilder
    private var bucketsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Recent Buckets")
                    .font(.headline)
                    .foregroundStyle(.primary)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top, 10)

            // Only 4 most recent buckets
            let recentBuckets = Array(dataStore.collections
                .sorted { $0.lastModifiedDate > $1.lastModifiedDate }
                .prefix(4))

            if recentBuckets.isEmpty {
                Text("No buckets yet — create one in Library")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)
                    .padding(.bottom, 6)
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(recentBuckets) { col in
                            Button { selectedCollection = col } label: {
                                BucketCardView(
                                    collection: col,
                                    recordingCount: dataStore.recordingCount(for: col.id)
                                )
                            }
                            .buttonStyle(.plain)
                            .contextMenu {
                                Button { selectedCollection = col } label: {
                                    Label("Open", systemImage: "folder")
                                }
                                Divider()
                                Button(role: .destructive) {
                                    dataStore.deleteCollection(col)
                                } label: {
                                    Label("Delete Bucket", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding(.horizontal)
                }
            }
        }
        .padding(.bottom, 8)
    }

    // MARK: - Favorites Section

    @ViewBuilder
    private var favoritesSection: some View {
        let favs = dataStore.sortedRecordings.filter { $0.isFavorite }
        if !favs.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Favorites")
                        .font(.headline).foregroundStyle(.primary)
                    Spacer()
                }
                .padding(.horizontal).padding(.top, 10)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(favs) { rec in
                            Button { selectedRecording = rec } label: {
                                RecordingCardView(recording: rec, isCompact: true)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal).padding(.vertical, 4)
                }
            }
        }
    }

    // MARK: - Helpers

    private var filteredRecordings: [Recording] {
        let sorted = dataStore.sortedRecordings
        guard !searchText.isEmpty else { return sorted }
        return sorted.filter { $0.title.localizedCaseInsensitiveContains(searchText) }
    }
}

// MARK: - Floating Card

private struct FloatingCardView: View {
    let recording: Recording
    let width: CGFloat
    let height: CGFloat
    @Environment(\.colorScheme) private var colorScheme

    private var isDark: Bool { colorScheme == .dark }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(recording.formattedTime)
                    .font(.system(size: 11, weight: .medium, design: .monospaced))
                    .foregroundStyle(recording.accentColor)
                Spacer()
                if recording.isFavorite {
                    Image(systemName: "star.fill")
                        .font(.system(size: 10))
                        .foregroundStyle(.yellow)
                } else {
                    Image(systemName: "waveform")
                        .font(.system(size: 11))
                        .foregroundStyle(recording.accentColor)
                }
            }

            Text(recording.title)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(isDark ? .white : .primary)
                .lineLimit(2)

            Spacer(minLength: 2)

            Text(recording.formattedDuration)
                .font(.system(size: 11, weight: .medium, design: .monospaced))
                .foregroundStyle(recording.accentColor.opacity(0.8))

            WaveformView(
                samples: Array(recording.waveformSamples.prefix(10)),
                color: recording.accentColor,
                barWidth: 2.5,
                spacing: 2
            )
            .frame(height: 16)
        }
        .padding(12)
        .frame(width: width, height: height)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(isDark ? Color(red: 0.11, green: 0.11, blue: 0.12) : recording.accentBackgroundColor)
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .strokeBorder(Color.white.opacity(isDark ? 0.08 : 0), lineWidth: 1)
                )
                .shadow(color: .black.opacity(isDark ? 0.3 : 0.06), radius: isDark ? 12 : 8, y: isDark ? 4 : 3)
        )
        .overlay(
            Group {
                if isDark {
                    // Top-edge highlight
                    LinearGradient(
                        colors: [.white.opacity(0.15), .white.opacity(0.05), .clear, .clear],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .allowsHitTesting(false)
                }
            }
        )
        .overlay(
            Group {
                if isDark {
                    // Accent color edge glow
                    RoundedRectangle(cornerRadius: 16)
                        .strokeBorder(
                            LinearGradient(
                                colors: [recording.accentColor.opacity(0.35), recording.accentColor.opacity(0.1), .clear],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                        .allowsHitTesting(false)
                }
            }
        )
    }
}
