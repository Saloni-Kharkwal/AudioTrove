import AVFoundation
import Foundation
import SwiftUI

@MainActor
@Observable
class AudioManager: NSObject {
    var isRecording = false
    var isPaused = false
    var isPlaying = false
    var currentTime: TimeInterval = 0
    var duration: TimeInterval = 0
    var audioLevels: [CGFloat] = []
    var playbackProgress: Double = 0
    var micPermissionGranted: Bool = false
    var micPermissionDenied: Bool = false

    enum EditMode { case none, replace, append }
    var editMode: EditMode = .none

    private var audioRecorder: AVAudioRecorder?
    private var audioPlayer: AVAudioPlayer?
    private var timerTask: Task<Void, Never>?
    private var levelTask: Task<Void, Never>?
    private var currentRecordingURL: URL?
    private var editTargetURL: URL?
    private var editOffset: TimeInterval = 0

    // Exposed for EditRecordingSheet merge flow
    private(set) var currentEditTargetURL: URL? = nil
    private(set) var currentEditOffset: TimeInterval = 0
    // Backup URL for Undo (set before any edit)
    private(set) var originalBackupURL: URL? = nil

    override init() {
        super.init()
    }

    // MARK: - Microphone Permission

    nonisolated func requestMicrophonePermission(completion: @escaping @Sendable (Bool) -> Void) {
        AVAudioSession.sharedInstance().requestRecordPermission { granted in
            Task { @MainActor in
                completion(granted)
            }
        }
    }

    nonisolated func currentMicPermission() -> AVAudioSession.RecordPermission {
        return AVAudioSession.sharedInstance().recordPermission
    }

    // MARK: - Recording

    func startRecording() {
        setupAudioSession()
        let fileName = "recording_\(UUID().uuidString).m4a"
        let url = documentsURL().appendingPathComponent(fileName)
        currentRecordingURL = url
        editMode = .none
        beginRecordingToURL(url)
    }

    func startReplaceRecording(targetURL: URL, at offset: TimeInterval) {
        setupAudioSession()
        // Make a backup before first edit
        if originalBackupURL == nil {
            originalBackupURL = makeBackup(of: targetURL)
        }
        editTargetURL = targetURL
        editOffset = offset
        currentEditTargetURL = targetURL
        currentEditOffset = offset
        editMode = .replace
        let tempURL = documentsURL().appendingPathComponent("replace_\(UUID().uuidString).m4a")
        currentRecordingURL = tempURL
        beginRecordingToURL(tempURL)
    }

    func startAppendRecording(targetURL: URL, at offset: TimeInterval = 0) {
        setupAudioSession()
        // Make a backup before first edit
        if originalBackupURL == nil {
            originalBackupURL = makeBackup(of: targetURL)
        }
        editTargetURL = targetURL
        currentEditTargetURL = targetURL
        currentEditOffset = offset
        editMode = .append
        let tempURL = documentsURL().appendingPathComponent("append_\(UUID().uuidString).m4a")
        currentRecordingURL = tempURL
        beginRecordingToURL(tempURL)
    }

    func clearBackup() {
        if let url = originalBackupURL {
            try? FileManager.default.removeItem(at: url)
        }
        originalBackupURL = nil
    }

    private func makeBackup(of url: URL) -> URL? {
        let backupURL = documentsURL().appendingPathComponent("backup_\(UUID().uuidString).m4a")
        try? FileManager.default.copyItem(at: url, to: backupURL)
        return backupURL
    }

    private func beginRecordingToURL(_ url: URL) {
        let settings: [String: Any] = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 44100,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        do {
            audioRecorder = try AVAudioRecorder(url: url, settings: settings)
            audioRecorder?.isMeteringEnabled = true
            audioRecorder?.record()
            isRecording = true
            isPaused = false
            currentTime = 0
            audioLevels = []
            startRecordingTimers()
        } catch {
            print("Failed to start recording: \(error)")
        }
    }

    func pauseRecording() {
        audioRecorder?.pause()
        isPaused = true
        cancelTimers()
    }

    func resumeRecording() {
        audioRecorder?.record()
        isPaused = false
        startRecordingTimers()
    }

    func stopRecording() -> (URL?, TimeInterval) {
        let url = currentRecordingURL
        let recorded = currentTime
        audioRecorder?.stop()
        audioRecorder = nil
        isRecording = false
        isPaused = false
        cancelTimers()
        return (url, recorded)
    }

    // MARK: - Audio Merging (AVMutableComposition)

    func mergeAudio(
        original originalURL: URL,
        newClip clipURL: URL,
        mode: EditMode,
        offset: TimeInterval = 0
    ) async -> URL? {
        return await Task.detached(priority: .userInitiated) {
            let composition = AVMutableComposition()
            let originalAsset = AVURLAsset(url: originalURL)
            let clipAsset    = AVURLAsset(url: clipURL)

            do {
                let origTracks = try await originalAsset.loadTracks(withMediaType: .audio)
                let clipTracks = try await clipAsset.loadTracks(withMediaType: .audio)
                guard let origSrc = origTracks.first, let clipSrc = clipTracks.first else { return nil }

                let origDuration = try await originalAsset.load(.duration)
                let clipDuration = try await clipAsset.load(.duration)

                guard
                    let origTrack = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid),
                    let clipTrack = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
                else { return nil }

                switch mode {
                case .append:
                    let offsetTime = CMTime(seconds: offset, preferredTimescale: 44100)
                    if offset > 0 && CMTimeCompare(offsetTime, origDuration) < 0 {
                        // Keep original up to the offset, then append new clip
                        try origTrack.insertTimeRange(CMTimeRange(start: .zero, duration: offsetTime), of: origSrc, at: .zero)
                        try clipTrack.insertTimeRange(CMTimeRange(start: .zero, duration: clipDuration), of: clipSrc, at: offsetTime)
                    } else {
                        // Normal: append clip to end of original
                        try origTrack.insertTimeRange(CMTimeRange(start: .zero, duration: origDuration), of: origSrc, at: .zero)
                        try clipTrack.insertTimeRange(CMTimeRange(start: .zero, duration: clipDuration), of: clipSrc, at: origDuration)
                    }

                case .replace:
                    let offsetTime = CMTime(seconds: offset, preferredTimescale: 44100)
                    if offset > 0 {
                        try origTrack.insertTimeRange(CMTimeRange(start: .zero, duration: offsetTime), of: origSrc, at: .zero)
                    }
                    try clipTrack.insertTimeRange(CMTimeRange(start: .zero, duration: clipDuration), of: clipSrc, at: offsetTime)
                    let clipEnd = CMTimeAdd(offsetTime, clipDuration)
                    if CMTimeCompare(clipEnd, origDuration) < 0 {
                        let tailDuration = CMTimeSubtract(origDuration, clipEnd)
                        try origTrack.insertTimeRange(CMTimeRange(start: clipEnd, duration: tailDuration), of: origSrc, at: clipEnd)
                    }

                case .none:
                    break
                }

                let outputURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                    .appendingPathComponent("merged_\(UUID().uuidString).m4a")

                guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetAppleM4A) else { return nil }
                exporter.outputURL      = outputURL
                exporter.outputFileType = .m4a
                await exporter.export()

                if exporter.status == .completed {
                    try? FileManager.default.removeItem(at: clipURL)
                    return outputURL
                }
                return nil
            } catch {
                print("Merge failed: \(error)")
                return nil
            }
        }.value
    }

    // MARK: - Trim Audio

    /// Keep only the portion between startTime and endTime.
    func trimAudio(url: URL, startTime: TimeInterval, endTime: TimeInterval) async -> URL? {
        return await Task.detached(priority: .userInitiated) {
            let asset = AVURLAsset(url: url)
            let start = CMTime(seconds: startTime, preferredTimescale: 44100)
            let end   = CMTime(seconds: endTime,   preferredTimescale: 44100)
            let range = CMTimeRange(start: start, duration: CMTimeSubtract(end, start))

            let outputURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                .appendingPathComponent("trimmed_\(UUID().uuidString).m4a")

            guard let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else { return nil }
            exporter.outputURL       = outputURL
            exporter.outputFileType  = .m4a
            exporter.timeRange       = range
            await exporter.export()

            return exporter.status == .completed ? outputURL : nil
        }.value
    }

    /// Remove the portion between cutFrom and cutTo; join surrounding parts.
    func cutAudio(url: URL, cutFrom startTime: TimeInterval, to endTime: TimeInterval) async -> URL? {
        return await Task.detached(priority: .userInitiated) {
            let asset    = AVURLAsset(url: url)
            let composition = AVMutableComposition()

            do {
                let tracks = try await asset.loadTracks(withMediaType: .audio)
                guard let srcTrack = tracks.first else { return nil }
                let totalDuration = try await asset.load(.duration)

                guard let compTrack = composition.addMutableTrack(
                    withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid
                ) else { return nil }

                let cutStart = CMTime(seconds: startTime, preferredTimescale: 44100)
                let cutEnd   = CMTime(seconds: endTime,   preferredTimescale: 44100)
                var insertAt = CMTime.zero

                // Keep portion before the cut
                if startTime > 0.001 {
                    let beforeRange = CMTimeRange(start: .zero, duration: cutStart)
                    try compTrack.insertTimeRange(beforeRange, of: srcTrack, at: insertAt)
                    insertAt = cutStart
                }
                // Keep portion after the cut
                if CMTimeCompare(cutEnd, totalDuration) < 0 {
                    let afterDuration = CMTimeSubtract(totalDuration, cutEnd)
                    let afterRange    = CMTimeRange(start: cutEnd, duration: afterDuration)
                    try compTrack.insertTimeRange(afterRange, of: srcTrack, at: insertAt)
                }

                let outputURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                    .appendingPathComponent("cut_\(UUID().uuidString).m4a")

                guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetAppleM4A) else { return nil }
                exporter.outputURL      = outputURL
                exporter.outputFileType = .m4a
                await exporter.export()

                return exporter.status == .completed ? outputURL : nil
            } catch {
                print("Cut failed: \(error)")
                return nil
            }
        }.value
    }

    // MARK: - Playback

    func startPlayback(url: URL) {
        stopPlayback()
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.delegate = self
            audioPlayer?.prepareToPlay()
            duration = audioPlayer?.duration ?? 0
            audioPlayer?.play()
            isPlaying = true
            startPlaybackTimer()
        } catch {
            print("Playback failed: \(error)")
        }
    }

    func pausePlayback() {
        audioPlayer?.pause()
        isPlaying = false
        cancelTimers()
    }

    func resumePlayback() {
        audioPlayer?.play()
        isPlaying = true
        startPlaybackTimer()
    }

    func stopPlayback() {
        audioPlayer?.stop()
        audioPlayer = nil
        isPlaying = false
        currentTime = 0
        playbackProgress = 0
        cancelTimers()
    }

    func seek(to time: TimeInterval) {
        audioPlayer?.currentTime = time
        currentTime = time
        if let d = audioPlayer?.duration, d > 0 {
            playbackProgress = time / d
        }
    }

    func skipForward(_ seconds: TimeInterval = 10) {
        guard let player = audioPlayer else { return }
        seek(to: min(player.currentTime + seconds, player.duration))
    }

    func skipBackward(_ seconds: TimeInterval = 10) {
        guard let player = audioPlayer else { return }
        seek(to: max(player.currentTime - seconds, 0))
    }

    func deleteAudioFile(fileName: String) {
        try? FileManager.default.removeItem(at: documentsURL().appendingPathComponent(fileName))
    }

    // MARK: - Private Helpers

    private func setupAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("Audio session setup failed: \(error)")
        }
    }

    private func documentsURL() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    // MARK: - Timers (Task-based, ~60 fps for smooth playhead)

    private func startRecordingTimers() {
        timerTask = Task { @MainActor in
            while !Task.isCancelled {
                if isRecording && !isPaused {
                    currentTime = audioRecorder?.currentTime ?? 0
                }
                try? await Task.sleep(nanoseconds: 33_000_000) // ~30fps for recording
            }
        }
        levelTask = Task { @MainActor in
            while !Task.isCancelled {
                if let recorder = audioRecorder {
                    recorder.updateMeters()
                    let power = recorder.averagePower(forChannel: 0)
                    let normalized = CGFloat(max(0.0, (power + 50.0) / 50.0))
                    audioLevels.append(normalized)
                    if audioLevels.count > 200 { audioLevels.removeFirst() }
                }
                try? await Task.sleep(nanoseconds: 50_000_000)
            }
        }
    }

    private func startPlaybackTimer() {
        timerTask = Task { @MainActor in
            while !Task.isCancelled {
                if let player = audioPlayer {
                    currentTime = player.currentTime
                    if player.duration > 0 {
                        playbackProgress = min(1.0, player.currentTime / player.duration)
                    }
                }
                try? await Task.sleep(nanoseconds: 16_600_000) // ~60 fps
            }
        }
    }

    private func cancelTimers() {
        timerTask?.cancel()
        timerTask = nil
        levelTask?.cancel()
        levelTask = nil
    }
}

extension AudioManager: @preconcurrency AVAudioPlayerDelegate {
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        isPlaying = false
        // Stop at the END
        let dur = player.duration
        currentTime = dur
        playbackProgress = 1.0
        cancelTimers()
    }
}
