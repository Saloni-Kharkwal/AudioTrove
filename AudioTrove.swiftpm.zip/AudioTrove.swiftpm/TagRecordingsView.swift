import SwiftUI

// MARK: - Tag Recordings View

struct TagRecordingsView: View {
    @Environment(DataStore.self)    private var dataStore
    @Environment(AudioManager.self) private var audioManager
    @Environment(\.dismiss)         private var dismiss

    let tag: String
    @Binding var selectedRecording: Recording?

    private var recordings: [Recording] {
        dataStore.sortedRecordings.filter { $0.tags.contains(tag) }
    }

    var body: some View {
        NavigationStack {
            Group {
                if recordings.isEmpty {
                    VStack(spacing: 14) {
                        Spacer()
                        Image(systemName: "tag.slash")
                            .font(.system(size: 44)).foregroundStyle(Color(.systemGray4))
                        Text("No recordings tagged \"\(tag)\"")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Spacer()
                    }
                    .frame(maxWidth: .infinity)
                } else {
                    ScrollView(.vertical, showsIndicators: false) {
                        LazyVStack(spacing: 12) {
                            ForEach(recordings) { rec in
                                Button { selectedRecording = rec } label: {
                                    LibraryRecordingRow(recording: rec)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal).padding(.top, 8)
                    }
                }
            }
            .navigationTitle(tag)
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
