import SwiftUI

// MARK: - Library Search View

struct LibrarySearchView: View {
    @Environment(DataStore.self) private var dataStore
    @Environment(\.dismiss) private var dismiss
    @Binding var selectedRecording: Recording?

    @State private var searchText: String = ""
    @FocusState private var isSearchFocused: Bool

    var body: some View {
        VStack(spacing: 0) {

            // ── Search bar row ────────────────────────────────────────────
            HStack(spacing: 12) {

                // Pill
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundStyle(.secondary)

                    TextField("Search", text: $searchText)
                        .font(.system(size: 17))
                        .focused($isSearchFocused)
                        .submitLabel(.search)
                        .autocorrectionDisabled()

                    Spacer(minLength: 0)

                    if searchText.isEmpty {
                        Image(systemName: "mic.fill")
                            .font(.system(size: 16))
                            .foregroundStyle(.secondary)
                    } else {
                        Button { searchText = "" } label: {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 16))
                                .foregroundStyle(Color(.systemGray3))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 11)
                .background(
                    RoundedRectangle(cornerRadius: 22)
                        .fill(Color(.systemBackground))
                        .shadow(color: .black.opacity(0.07), radius: 6, x: 0, y: 2)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 22)
                        .strokeBorder(Color(.systemGray5), lineWidth: 0.5)
                )

                // ✕ dismiss button — slides in when keyboard is active
                if isSearchFocused {
                    Button {
                        isSearchFocused = false
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(.primary)
                            .frame(width: 36, height: 36)
                            .background(
                                Circle().fill(Color(.systemGray5))
                            )
                    }
                    .buttonStyle(.plain)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 16)
            .padding(.bottom, 10)
            .animation(.spring(response: 0.3, dampingFraction: 0.8), value: isSearchFocused)

            Divider()

            // ── Content ───────────────────────────────────────────────────
            if searchText.isEmpty {
                VStack(spacing: 14) {
                    Spacer()
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 44)).foregroundStyle(Color(.systemGray4))
                    Text("Search recordings, buckets and tags")
                        .font(.subheadline).foregroundStyle(.secondary)
                        .multilineTextAlignment(.center).padding(.horizontal, 40)
                    Spacer()
                }
            } else {
                ScrollView(.vertical, showsIndicators: false) {
                    LazyVStack(alignment: .leading, spacing: 24) {

                        if !matchedRecordings.isEmpty {
                            Section {
                                ForEach(matchedRecordings) { rec in
                                    Button { selectedRecording = rec } label: {
                                        LibraryRecordingRow(recording: rec)
                                    }.buttonStyle(.plain)
                                }
                            } header: { sectionLabel("Recordings") }
                        }

                        if !matchedCollections.isEmpty {
                            Section {
                                LazyVGrid(columns: [
                                    GridItem(.flexible(), spacing: 14),
                                    GridItem(.flexible(), spacing: 14)
                                ], spacing: 14) {
                                    ForEach(matchedCollections) { col in
                                        BucketCardView(collection: col,
                                                       recordingCount: dataStore.recordingCount(for: col.id))
                                    }
                                }
                            } header: { sectionLabel("Buckets") }
                        }

                        if matchedRecordings.isEmpty && matchedCollections.isEmpty {
                            VStack(spacing: 12) {
                                Spacer(minLength: 40)
                                Image(systemName: "exclamationmark.magnifyingglass")
                                    .font(.system(size: 44)).foregroundStyle(Color(.systemGray4))
                                Text("No results for \"\(searchText)\"")
                                    .font(.subheadline).foregroundStyle(.secondary)
                                Spacer()
                            }
                            .frame(maxWidth: .infinity)
                        }
                    }
                    .padding(.horizontal).padding(.top, 16)
                }
                .scrollDismissesKeyboard(.immediately)
            }
        }
    }

    // MARK: - Section header

    @ViewBuilder
    private func sectionLabel(_ title: String) -> some View {
        Text(title)
            .font(.headline).foregroundStyle(.primary)
            .padding(.top, 4)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(.systemGroupedBackground))
    }

    // MARK: - Filtering

    private var matchedRecordings: [Recording] {
        guard !searchText.isEmpty else { return [] }
        return dataStore.sortedRecordings.filter {
            $0.title.localizedCaseInsensitiveContains(searchText) ||
            $0.notes.localizedCaseInsensitiveContains(searchText) ||
            $0.tags.contains { $0.localizedCaseInsensitiveContains(searchText) }
        }
    }

    private var matchedCollections: [RecordingCollection] {
        guard !searchText.isEmpty else { return [] }
        return dataStore.collections.filter {
            $0.name.localizedCaseInsensitiveContains(searchText)
        }
    }
}
