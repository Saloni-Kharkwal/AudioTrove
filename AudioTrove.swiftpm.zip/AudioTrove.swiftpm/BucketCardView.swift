import SwiftUI

// MARK: - Bucket Card (Library Grid)

struct BucketCardView: View {
    let collection: RecordingCollection
    let recordingCount: Int
    @Environment(\.colorScheme) private var colorScheme

    private var isDark: Bool { colorScheme == .dark }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            RoundedRectangle(cornerRadius: 14)
                .fill(isDark ? Color(red: 0.11, green: 0.11, blue: 0.12) : collection.backgroundColor)
                .frame(height: 118)
                .overlay {
                    if let data = collection.coverImageData,
                       let uiImage = UIImage(data: data) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFill()
                            .clipped()
                    } else {
                        Image(systemName: collection.iconName)
                            .font(.system(size: 28))
                            .foregroundStyle(collection.color)
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .strokeBorder(Color.white.opacity(isDark ? 0.08 : 0), lineWidth: 1)
                )
                .overlay(
                    Group {
                        if isDark {
                            LinearGradient(
                                colors: [.white.opacity(0.15), .white.opacity(0.05), .clear, .clear],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .allowsHitTesting(false)
                        }
                    }
                )
                .overlay(
                    Group {
                        if isDark {
                            RoundedRectangle(cornerRadius: 14)
                                .strokeBorder(
                                    LinearGradient(
                                        colors: [collection.color.opacity(0.35), collection.color.opacity(0.1), .clear],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ),
                                    lineWidth: 1
                                )
                                .allowsHitTesting(false)
                        }
                    }
                )

            Text(collection.name)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(isDark ? .white : .primary)

            Text("\(recordingCount) recording\(recordingCount == 1 ? "" : "s")")
                .font(.system(size: 12))
                .foregroundStyle(.secondary)
        }
        .frame(width: 168)
    }
}

// MARK: - New Bucket Placeholder

struct NewBucketCardView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            RoundedRectangle(cornerRadius: 14)
                .fill(Color(.systemGray6))
                .frame(height: 100)
                .overlay(
                    Image(systemName: "plus")
                        .font(.system(size: 24, weight: .medium))
                        .foregroundStyle(.blue)
                )
            
            Text("New Bucket")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.primary)
            
            Text(" ")
                .font(.system(size: 12))
        }
        .frame(width: 150)
    }
}

// MARK: - Bucket Selection Card (used in SaveRecordingView picker)

struct BucketSelectionCardView: View {
    let collection: RecordingCollection
    let isSelected: Bool
    
    var body: some View {
        VStack(spacing: 6) {
            RoundedRectangle(cornerRadius: 12)
                .fill(collection.backgroundColor)
                .frame(width: 70, height: 70)
                .overlay {
                    if let data = collection.coverImageData,
                       let uiImage = UIImage(data: data) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFill()
                            .clipped()
                    } else {
                        Image(systemName: collection.iconName)
                            .font(.system(size: 22))
                            .foregroundStyle(collection.color)
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .strokeBorder(isSelected ? Color.blue : Color.clear, lineWidth: 2)
                )
            
            Text(collection.name)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.primary)
                .lineLimit(1)
        }
    }
}

// MARK: - Create New Bucket (in picker)

struct CreateNewBucketSelectionView: View {
    var body: some View {
        VStack(spacing: 6) {
            RoundedRectangle(cornerRadius: 12)
                .strokeBorder(style: StrokeStyle(lineWidth: 1.5, dash: [5]))
                .foregroundStyle(Color(.systemGray3))
                .frame(width: 70, height: 70)
                .overlay(
                    Image(systemName: "plus")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundStyle(.secondary)
                )
            
            Text("New")
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
    }
}
