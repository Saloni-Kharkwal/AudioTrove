import Foundation
import SwiftUI

// MARK: - Recording Model

struct Recording: Identifiable, Codable, Hashable, Sendable {
    var id: UUID
    var title: String
    var date: Date
    var duration: TimeInterval
    var isFavorite: Bool
    var collectionId: UUID?
    var notes: String
    var tags: [String]
    var audioFileName: String
    var waveformSamples: [CGFloat]
    var accentColorIndex: Int
    
    init(
        id: UUID = UUID(),
        title: String = "New Recording",
        date: Date = Date(),
        duration: TimeInterval = 0,
        isFavorite: Bool = false,
        collectionId: UUID? = nil,
        notes: String = "",
        tags: [String] = [],
        audioFileName: String = "",
        waveformSamples: [CGFloat] = [],
        accentColorIndex: Int = 0
    ) {
        self.id = id
        self.title = title
        self.date = date
        self.duration = duration
        self.isFavorite = isFavorite
        self.collectionId = collectionId
        self.notes = notes
        self.tags = tags
        self.audioFileName = audioFileName
        self.waveformSamples = waveformSamples.isEmpty ? Self.generateRandomWaveform() : waveformSamples
        self.accentColorIndex = accentColorIndex
    }
    
    var formattedDuration: String {
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
    
    var formattedDate: String {
        let calendar = Calendar.current
        if calendar.isDateInToday(date) {
            return "Today"
        } else if calendar.isDateInYesterday(date) {
            return "Yesterday"
        } else {
            let formatter = DateFormatter()
            formatter.dateFormat = "MMM d"
            return formatter.string(from: date)
        }
    }
    
    var formattedTime: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
    
    var audioURL: URL? {
        guard !audioFileName.isEmpty else { return nil }
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return documentsPath.appendingPathComponent(audioFileName)
    }
    
    var accentColor: Color {
        Self.cardColors[accentColorIndex % Self.cardColors.count]
    }
    
    var accentBackgroundColor: Color {
        Self.cardBackgroundColors[accentColorIndex % Self.cardBackgroundColors.count]
    }
    
    static let cardColors: [Color] = [
        Color(red: 0.95, green: 0.35, blue: 0.35),   // Soft red
        Color(red: 0.35, green: 0.55, blue: 0.95),   // Soft blue
        Color(red: 0.55, green: 0.78, blue: 0.65),   // Soft green/mint
        Color(red: 0.65, green: 0.55, blue: 0.85),   // Soft purple
        Color(red: 0.95, green: 0.65, blue: 0.35),   // Soft orange
    ]
    
    static let cardBackgroundColors: [Color] = [
        Color(red: 1.0, green: 0.92, blue: 0.92),    // Light red
        Color(red: 0.90, green: 0.93, blue: 1.0),    // Light blue
        Color(red: 0.90, green: 0.96, blue: 0.92),   // Light mint
        Color(red: 0.93, green: 0.90, blue: 1.0),    // Light purple
        Color(red: 1.0, green: 0.95, blue: 0.90),    // Light orange
    ]
    
    static func generateRandomWaveform(count: Int = 80) -> [CGFloat] {
        (0..<count).map { _ in CGFloat.random(in: 0.15...1.0) }
    }
}

// MARK: - Collection (Bucket) Model

struct RecordingCollection: Identifiable, Codable, Hashable, Sendable {
    var id: UUID
    var name: String
    var iconName: String
    var colorIndex: Int
    var coverImageData: Data?
    var lastModifiedDate: Date

    init(
        id: UUID = UUID(),
        name: String = "New Collection",
        iconName: String = "folder.fill",
        colorIndex: Int = 0,
        coverImageData: Data? = nil,
        lastModifiedDate: Date = Date()
    ) {
        self.id = id
        self.name = name
        self.iconName = iconName
        self.colorIndex = colorIndex
        self.coverImageData = coverImageData
        self.lastModifiedDate = lastModifiedDate
    }
    
    var color: Color {
        Self.collectionColors[colorIndex % Self.collectionColors.count]
    }
    
    var backgroundColor: Color {
        Self.collectionBackgrounds[colorIndex % Self.collectionBackgrounds.count]
    }
    
    static let collectionColors: [Color] = [
        Color(red: 0.35, green: 0.55, blue: 0.95),  // Blue
        Color(red: 0.55, green: 0.78, blue: 0.65),  // Green
        Color(red: 0.95, green: 0.65, blue: 0.35),  // Orange
        Color(red: 0.65, green: 0.55, blue: 0.85),  // Purple
        Color(red: 0.95, green: 0.35, blue: 0.35),  // Red
    ]
    
    static let collectionBackgrounds: [Color] = [
        Color(red: 0.92, green: 0.95, blue: 1.0),
        Color(red: 0.92, green: 0.97, blue: 0.93),
        Color(red: 1.0, green: 0.96, blue: 0.92),
        Color(red: 0.95, green: 0.92, blue: 1.0),
        Color(red: 1.0, green: 0.93, blue: 0.93),
    ]
    
    static let availableIcons: [String] = [
        "folder.fill", "star.fill", "heart.fill", "music.note",
        "briefcase.fill", "book.fill", "camera.fill", "flag.fill",
        "gift.fill", "house.fill", "leaf.fill", "paintbrush.fill",
        "mic.fill", "headphones", "gamecontroller.fill", "trophy.fill"
    ]
}

// MARK: - Tag Model

struct Tag: Identifiable, Codable, Hashable, Sendable {
    var id: UUID
    var name: String
    var iconName: String
    
    init(
        id: UUID = UUID(),
        name: String,
        iconName: String = "tag.fill"
    ) {
        self.id = id
        self.name = name
        self.iconName = iconName
    }
    
    static let availableIcons: [String] = [
        "tag.fill", "star.fill", "lightbulb.fill", "heart.fill",
        "person.2.fill", "music.note", "face.smiling", "bolt.fill",
        "flame.fill", "pencil", "book.fill", "flag.fill",
        "bell.fill", "bookmark.fill", "pin.fill", "mappin"
    ]
    
    static let defaultTags: [Tag] = [
        Tag(name: "Important", iconName: "star.fill"),
        Tag(name: "Idea",      iconName: "lightbulb.fill"),
        Tag(name: "Personal",  iconName: "heart.fill"),
    ]
}
