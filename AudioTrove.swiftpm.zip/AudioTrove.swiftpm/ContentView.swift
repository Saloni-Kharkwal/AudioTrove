import SwiftUI

// Carries both pieces of data needed by SaveRecordingView as a single identifiable item.
// Using sheet(item:) guarantees SwiftUI re-evaluates the content builder with the latest
// value each time — avoids the blank-sheet bug caused by isPresented + if-let lagging.
private struct SavePayload: Identifiable {
    let id   = UUID()
    let url  : URL
    let duration: TimeInterval
}

struct ContentView: View {
    @State private var dataStore    = DataStore()
    @State private var audioManager = AudioManager()
    @State private var selectedTab  = 0
    @State private var showRecordSheet  = false
    @State private var selectedRecording: Recording?

    // Save flow — single optional drives the sheet
    @State private var savePayload: SavePayload?

    // Space search
    @State private var spaceSearchText = ""
    @State private var showSpaceSearch = false

    var body: some View {
        TabView(selection: $selectedTab) {
            SpaceView(
                showRecordSheet:   $showRecordSheet,
                selectedRecording: $selectedRecording,
                searchText:  $spaceSearchText,
                showSearch:  $showSpaceSearch
            )
            .tabItem { Label("Space",   systemImage: "square.grid.2x2.fill") }
            .tag(0)

            LibraryView(
                selectedRecording: $selectedRecording,
                showSearch: .constant(false)
            )
            .tabItem { Label("Library", systemImage: "folder.fill") }
            .tag(1)

            LibrarySearchView(selectedRecording: $selectedRecording)
                .tabItem { Label("Search", systemImage: "magnifyingglass") }
                .tag(2)
        }
        .tint(.blue)
        .environment(dataStore)
        .environment(audioManager)
        // Mini recording sheet
        .sheet(isPresented: $showRecordSheet) {
            RecordingModalView { url, duration in
                // Small delay so recording sheet fully dismisses before save sheet appears
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    savePayload = SavePayload(url: url, duration: duration)
                }
            }
            .environment(audioManager)
            .environment(dataStore)
            .presentationDetents([.height(300)])
            .presentationCornerRadius(24)
            .presentationDragIndicator(.hidden)
            .interactiveDismissDisabled()
        }
        // Save sheet — item: guarantees content is always built with a fresh, non-nil payload
        .sheet(item: $savePayload) { payload in
            SaveRecordingView(audioURL: payload.url, recordingDuration: payload.duration)
                .environment(dataStore)
                .environment(audioManager)
                .interactiveDismissDisabled()
        }
        // Tap card → detail
        .sheet(item: $selectedRecording) { recording in
            RecordingDetailView(recording: recording)
                .environment(dataStore)
                .environment(audioManager)
        }
    }
}
