import SwiftUI

struct SaveRecordingView: View {
    @Environment(DataStore.self) private var dataStore
    @Environment(AudioManager.self) private var audioManager
    @Environment(\.dismiss) private var dismiss
    
    let audioURL: URL
    let recordingDuration: TimeInterval
    
    @State private var title: String = ""
    @State private var selectedTags: Set<String> = []
    @State private var notes: String = ""
    @State private var selectedCollectionId: UUID?
    
    // New tag creation
    @State private var showNewTagSheet = false
    @State private var newTagName = ""
    @State private var newTagIcon = "tag.fill"
    
    // New collection creation
    @State private var showNewCollectionSheet = false
    @State private var newCollectionName = ""
    @State private var newCollectionIcon = "folder.fill"
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    // Title
                    VStack(alignment: .leading, spacing: 8) {
                        Text("TITLE")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(.secondary)
                            .tracking(1)
                        
                        TextField("New Recording", text: $title)
                            .font(.system(size: 22, weight: .bold))
                            .onChange(of: title) { _, newValue in
                                if newValue.count > 25 {
                                    title = String(newValue.prefix(25))
                                }
                            }
                        
                        HStack {
                            if isDuplicateTitle {
                                Label("Name already taken", systemImage: "exclamationmark.circle.fill")
                                    .font(.system(size: 11, weight: .medium))
                                    .foregroundStyle(Color.red)
                            }
                            Spacer()
                            Text("\(title.count)/25")
                                .font(.system(size: 11, weight: .medium))
                                .foregroundStyle(title.count >= 25 ? AnyShapeStyle(Color.red) : AnyShapeStyle(HierarchicalShapeStyle.tertiary))
                        }
                        
                        Divider()
                    }
                    
                    // Tags
                    VStack(alignment: .leading, spacing: 10) {
                        Text("TAGS")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(.secondary)
                            .tracking(1)
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(dataStore.tags) { tag in
                                    tagPill(tag)
                                }
                                
                                // Add new tag
                                Button {
                                    showNewTagSheet = true
                                } label: {
                                    HStack(spacing: 5) {
                                        Image(systemName: "plus")
                                            .font(.system(size: 11, weight: .semibold))
                                        Text("Add Tag")
                                            .font(.system(size: 13, weight: .medium))
                                    }
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(
                                        Capsule()
                                            .strokeBorder(Color(.systemGray3), style: StrokeStyle(lineWidth: 1, dash: [4]))
                                    )
                                    .foregroundStyle(.secondary)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    
                    // Notes
                    VStack(alignment: .leading, spacing: 8) {
                        Text("NOTES / LYRICS")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(.secondary)
                            .tracking(1)
                        
                        TextEditor(text: $notes)
                            .font(.system(size: 15))
                            .frame(minHeight: 120)
                            .padding(8)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color(.systemGray6))
                            )
                            .overlay(alignment: .topLeading) {
                                if notes.isEmpty {
                                    Text("Write down lyrics, chords, or notes here...")
                                        .font(.system(size: 15))
                                        .foregroundStyle(HierarchicalShapeStyle.tertiary)
                                        .padding(.horizontal, 12)
                                        .padding(.vertical, 16)
                                        .allowsHitTesting(false)
                                }
                            }
                    }
                    
                    // Save to Bucket
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text("SAVE TO BUCKET")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(.secondary)
                                .tracking(1)
                            
                            Spacer()
                            
                            Button("Manage") { }
                                .font(.system(size: 14, weight: .medium))
                        }
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 14) {
                                Button {
                                    showNewCollectionSheet = true
                                } label: {
                                    CreateNewBucketSelectionView()
                                }
                                .buttonStyle(.plain)
                                
                                ForEach(dataStore.collections) { collection in
                                    Button {
                                        if selectedCollectionId == collection.id {
                                            selectedCollectionId = nil
                                        } else {
                                            selectedCollectionId = collection.id
                                        }
                                    } label: {
                                        BucketSelectionCardView(
                                            collection: collection,
                                            isSelected: selectedCollectionId == collection.id
                                        )
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("New Recording")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        // Delete the recorded file
                        try? FileManager.default.removeItem(at: audioURL)
                        audioManager.stopPlayback()
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        saveRecording()
                    }
                    .fontWeight(.semibold)
                    .disabled(isDuplicateTitle)
                }
            }
            .sheet(isPresented: $showNewTagSheet) {
                newTagSheet
            }
            .sheet(isPresented: $showNewCollectionSheet) {
                newCollectionSheet
            }
            .onDisappear {
                audioManager.stopPlayback()
            }
        }
    }
    


    // MARK: - Tag Pill
    
    private func tagPill(_ tag: Tag) -> some View {
        let isSelected = selectedTags.contains(tag.name)
        
        return Button {
            if isSelected {
                selectedTags.remove(tag.name)
            } else {
                selectedTags.insert(tag.name)
            }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: tag.iconName)
                    .font(.system(size: 11))
                Text(tag.name)
                    .font(.system(size: 13, weight: .medium))
                    .fixedSize(horizontal: true, vertical: false)
                    .layoutPriority(1)
            }
            .fixedSize(horizontal: true, vertical: false)
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
                Capsule()
                    .fill(isSelected ? Color.blue.opacity(0.12) : Color(.systemGray6))
            )
            .overlay(
                Capsule()
                    .strokeBorder(isSelected ? Color.blue.opacity(0.3) : Color.clear, lineWidth: 1)
            )
            .foregroundStyle(isSelected ? .blue : .secondary)
        }
        .buttonStyle(.plain)
    }
    
    // MARK: - New Tag Sheet
    
    private var newTagSheet: some View {
        NavigationStack {
            VStack(spacing: 20) {
                TextField("Tag name", text: $newTagName)
                    .font(.system(size: 18, weight: .medium))
                    .padding(12)
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color(.systemGray6)))
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("CHOOSE ICON")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(.secondary)
                        .tracking(1)
                    
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 4), spacing: 12) {
                        ForEach(Tag.availableIcons, id: \.self) { icon in
                            Button {
                                newTagIcon = icon
                            } label: {
                                Image(systemName: icon)
                                    .font(.system(size: 20))
                                    .frame(width: 50, height: 50)
                                    .background(
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(newTagIcon == icon ? Color.blue.opacity(0.12) : Color(.systemGray6))
                                    )
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10)
                                            .strokeBorder(newTagIcon == icon ? Color.blue : Color.clear, lineWidth: 1.5)
                                    )
                                    .foregroundStyle(newTagIcon == icon ? .blue : .secondary)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("New Tag")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        newTagName = ""
                        newTagIcon = "tag.fill"
                        showNewTagSheet = false
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") {
                        if !newTagName.isEmpty {
                            let tag = Tag(name: newTagName, iconName: newTagIcon)
                            dataStore.addTag(tag)
                            newTagName = ""
                            newTagIcon = "tag.fill"
                            showNewTagSheet = false
                        }
                    }
                    .fontWeight(.semibold)
                    .disabled(newTagName.isEmpty)
                }
            }
        }
        .presentationDetents([.medium])
    }
    
    // MARK: - New Collection Sheet
    
    private var newCollectionSheet: some View {
        NavigationStack {
            VStack(spacing: 20) {
                TextField("Bucket name", text: $newCollectionName)
                    .font(.system(size: 18, weight: .medium))
                    .padding(12)
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color(.systemGray6)))
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("CHOOSE ICON")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(.secondary)
                        .tracking(1)
                    
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 4), spacing: 12) {
                        ForEach(RecordingCollection.availableIcons, id: \.self) { icon in
                            Button {
                                newCollectionIcon = icon
                            } label: {
                                Image(systemName: icon)
                                    .font(.system(size: 20))
                                    .frame(width: 50, height: 50)
                                    .background(
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(newCollectionIcon == icon ? Color.blue.opacity(0.12) : Color(.systemGray6))
                                    )
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10)
                                            .strokeBorder(newCollectionIcon == icon ? Color.blue : Color.clear, lineWidth: 1.5)
                                    )
                                    .foregroundStyle(newCollectionIcon == icon ? .blue : .secondary)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("New Bucket")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        newCollectionName = ""
                        newCollectionIcon = "folder.fill"
                        showNewCollectionSheet = false
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Create") {
                        if !newCollectionName.isEmpty {
                            let collection = RecordingCollection(
                                name: newCollectionName,
                                iconName: newCollectionIcon,
                                colorIndex: dataStore.collections.count
                            )
                            dataStore.addCollection(collection)
                            selectedCollectionId = collection.id
                            newCollectionName = ""
                            newCollectionIcon = "folder.fill"
                            showNewCollectionSheet = false
                        }
                    }
                    .fontWeight(.semibold)
                    .disabled(newCollectionName.isEmpty)
                }
            }
        }
        .presentationDetents([.medium])
    }
    
    // MARK: - Helpers
    
    /// Only flag a duplicate when the user has actually typed something.
    /// An empty title gets an auto-generated unique name, so it's never a conflict.
    private var isDuplicateTitle: Bool {
        let effective = title.trimmingCharacters(in: .whitespaces)
        guard !effective.isEmpty else { return false }
        return dataStore.titleExists(effective)
    }
    
    /// Returns the first unused name in the sequence:
    /// "New Recording" → "New Recording 2" → "New Recording 3" → …
    private func nextAvailableTitle(base: String = "New Recording") -> String {
        if !dataStore.titleExists(base) { return base }
        var counter = 2
        while true {
            let candidate = "\(base) \(counter)"
            if !dataStore.titleExists(candidate) { return candidate }
            counter += 1
        }
    }
    
    private func saveRecording() {
        audioManager.stopPlayback()
        let fileName = audioURL.lastPathComponent
        let typed = title.trimmingCharacters(in: .whitespaces)
        let finalTitle = typed.isEmpty ? nextAvailableTitle() : typed
        
        let recording = Recording(
            title: finalTitle,
            date: Date(),
            duration: recordingDuration,
            collectionId: selectedCollectionId,
            notes: notes,
            tags: Array(selectedTags),
            audioFileName: fileName,
            accentColorIndex: dataStore.nextColorIndex()
        )
        
        dataStore.addRecording(recording)
        dismiss()
    }
}

