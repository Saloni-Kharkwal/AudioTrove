import SwiftUI
import PhotosUI

struct CollectionDetailView: View {
    @Environment(DataStore.self) private var dataStore
    @Environment(\.dismiss) private var dismiss
    
    let collection: RecordingCollection
    @Binding var selectedRecording: Recording?
    
    @State private var photoPickerItem: PhotosPickerItem?
    @State private var showingPhotoPicker = false
    
    var recordings: [Recording] {
        dataStore.recordings(for: collection.id)
    }
    
    // Live collection (with cover updates reflected)
    var liveCollection: RecordingCollection {
        dataStore.collections.first(where: { $0.id == collection.id }) ?? collection
    }
    
    var body: some View {
        NavigationStack {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {
                    
                    // MARK: Cover Image Header
                    ZStack(alignment: .bottomLeading) {
                        Group {
                            if let data = liveCollection.coverImageData,
                               let uiImage = UIImage(data: data) {
                                Image(uiImage: uiImage)
                                    .resizable()
                                    .scaledToFill()
                            } else {
                                liveCollection.backgroundColor
                                    .overlay {
                                        Image(systemName: liveCollection.iconName)
                                            .font(.system(size: 52))
                                            .foregroundStyle(liveCollection.color)
                                    }
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 180)
                        .clipped()
                        
                        // Camera button to change/add photo
                        PhotosPicker(
                            selection: $photoPickerItem,
                            matching: .images
                        ) {
                            HStack(spacing: 6) {
                                Image(systemName: liveCollection.coverImageData == nil ? "camera.fill" : "photo.fill")
                                    .font(.system(size: 13, weight: .semibold))
                                Text(liveCollection.coverImageData == nil ? "Add Cover" : "Change Cover")
                                    .font(.system(size: 13, weight: .semibold))
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(.ultraThinMaterial, in: Capsule())
                            .foregroundStyle(.primary)
                        }
                        .padding(14)
                    }
                    
                    // MARK: Recordings
                    if recordings.isEmpty {
                        VStack(spacing: 14) {
                            Image(systemName: "waveform")
                                .font(.system(size: 36))
                                .foregroundStyle(.secondary)
                            Text("No recordings yet")
                                .font(.system(size: 16))
                                .foregroundStyle(.secondary)
                            Text("Assign recordings to this bucket\nfrom the recording detail screen.")
                                .font(.system(size: 14))
                                .foregroundStyle(.tertiary)
                                .multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.top, 60)
                    } else {
                        LazyVStack(spacing: 12) {
                            ForEach(recordings) { recording in
                                Button {
                                    selectedRecording = recording
                                    dismiss()
                                } label: {
                                    LibraryRecordingRow(recording: recording)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal)
                        .padding(.top, 20)
                    }
                }
            }
            .navigationTitle(liveCollection.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .onChange(of: photoPickerItem) { _, newItem in
                guard let newItem else { return }
                Task {
                    if let data = try? await newItem.loadTransferable(type: Data.self) {
                        var updated = liveCollection
                        updated.coverImageData = data
                        dataStore.updateCollection(updated)
                    }
                }
            }
        }
    }
}
