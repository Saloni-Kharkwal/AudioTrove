import SwiftUI

struct RecordingCardView: View {
    let recording: Recording
    var isLarge:   Bool = false
    var isCompact: Bool = false
    @Environment(\.colorScheme) private var colorScheme

    private var isDark: Bool { colorScheme == .dark }

    var body: some View {
        VStack(alignment: .leading, spacing: isCompact ? 5 : 8) {
            HStack {
                Text(recording.formattedTime)
                    .font(.system(size: isCompact ? 10 : 11, weight: .medium, design: .monospaced))
                    .foregroundStyle(recording.accentColor)
                Spacer()
                Image(systemName: "waveform")
                    .font(.system(size: isCompact ? 10 : 11))
                    .foregroundStyle(recording.accentColor)
            }

            Text(recording.title)
                .font(.system(size: isLarge ? 16 : (isCompact ? 12 : 14), weight: .semibold))
                .foregroundStyle(isDark ? .white : .primary)
                .lineLimit(isCompact ? 1 : 2)

            Spacer(minLength: 2)

            WaveformView(
                samples: Array(recording.waveformSamples.prefix(isCompact ? 10 : 12)),
                color: recording.accentColor,
                barWidth: isCompact ? 2.0 : 2.5,
                spacing: 2
            )
            .frame(height: isCompact ? 18 : 18)
        }
        .padding(isCompact ? 13 : 14)
        .frame(
            width:  isLarge ? 170 : (isCompact ? 168 : 150),
            height: isLarge ? 140 : (isCompact ? 118 : 120)
        )
        .background(
            RoundedRectangle(cornerRadius: 15)
                .fill(isDark ? Color(red: 0.11, green: 0.11, blue: 0.12) : recording.accentBackgroundColor)
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .strokeBorder(Color.white.opacity(isDark ? 0.08 : 0), lineWidth: 1)
                )
                .shadow(color: .black.opacity(isDark ? 0.3 : 0.06), radius: isDark ? 12 : 8, y: isDark ? 4 : 3)
        )
        .overlay(
            Group {
                if isDark {
                    LinearGradient(
                        colors: [.white.opacity(0.15), .white.opacity(0.05), .clear, .clear],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 15))
                    .allowsHitTesting(false)
                }
            }
        )
        .overlay(
            Group {
                if isDark {
                    RoundedRectangle(cornerRadius: 15)
                        .strokeBorder(
                            LinearGradient(
                                colors: [recording.accentColor.opacity(0.35), recording.accentColor.opacity(0.1), .clear],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                        .allowsHitTesting(false)
                }
            }
        )
    }
}

struct SmallRecordingCardView: View {
    let recording: Recording
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(recording.formattedDate)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(.secondary)
                
                Spacer()
                
                Image(systemName: "mic.fill")
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
            }
            
            Text(recording.title)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(.primary)
                .lineLimit(1)
            
            Spacer(minLength: 2)
            
            WaveformView(
                samples: Array(recording.waveformSamples.prefix(8)),
                color: .secondary.opacity(0.6),
                barWidth: 2,
                spacing: 2
            )
            .frame(height: 14)
        }
        .padding(12)
        .frame(width: 150, height: 90)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(Color(.systemGray6))
        )
    }
}

struct FavoriteRecordingCardView: View {
    let recording: Recording
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(recording.formattedTime)
                    .font(.system(size: 11, weight: .medium, design: .monospaced))
                    .foregroundStyle(recording.accentColor)
                
                Spacer()
                
                Image(systemName: "waveform")
                    .font(.system(size: 10))
                    .foregroundStyle(recording.accentColor)
            }
            
            Text(recording.title)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.primary)
                .lineLimit(1)
            
            Spacer(minLength: 2)
            
            WaveformView(
                samples: Array(recording.waveformSamples.prefix(10)),
                color: recording.accentColor,
                barWidth: 2,
                spacing: 2
            )
            .frame(height: 14)
        }
        .padding(12)
        .frame(width: 165, height: 100)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(recording.accentBackgroundColor.opacity(0.6))
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .strokeBorder(Color(.systemGray4).opacity(0.4), lineWidth: 0.5)
                )
        )
    }
}
