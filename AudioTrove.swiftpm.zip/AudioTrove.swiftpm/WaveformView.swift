import SwiftUI

struct WaveformView: View {
    let samples: [CGFloat]
    var color: Color = .blue
    var barWidth: CGFloat = 2
    var spacing: CGFloat = 1.5
    var isAnimating: Bool = false
    
    @State private var animationPhase: CGFloat = 0
    
    var body: some View {
        HStack(alignment: .center, spacing: spacing) {
            ForEach(Array(samples.enumerated()), id: \.offset) { index, sample in
                RoundedRectangle(cornerRadius: barWidth / 2)
                    .fill(color)
                    .frame(width: barWidth, height: max(3, barHeight(for: sample, at: index)))
            }
        }
        .onAppear {
            if isAnimating {
                withAnimation(.easeInOut(duration: 1.0).repeatForever(autoreverses: true)) {
                    animationPhase = 1.0
                }
            }
        }
    }
    
    private func barHeight(for sample: CGFloat, at index: Int) -> CGFloat {
        let base = sample * 24
        if isAnimating {
            let offset = sin(CGFloat(index) * 0.5 + animationPhase * .pi * 2) * 4
            return max(3, base + offset)
        }
        return base
    }
}

// MARK: - Live Recording Waveform

struct LiveWaveformView: View {
    let levels: [CGFloat]
    var color: Color = .blue
    
    var body: some View {
        HStack(alignment: .center, spacing: 1.5) {
            ForEach(Array(displayLevels.enumerated()), id: \.offset) { _, level in
                RoundedRectangle(cornerRadius: 1)
                    .fill(color)
                    .frame(width: 2, height: max(3, level * 30))
            }
        }
        .frame(height: 30)
        .animation(.easeOut(duration: 0.08), value: levels.count)
    }
    
    private var displayLevels: [CGFloat] {
        let targetCount = 40
        if levels.isEmpty {
            return Array(repeating: 0.08, count: targetCount)
        }
        if levels.count >= targetCount {
            return Array(levels.suffix(targetCount))
        }
        let padding = Array(repeating: CGFloat(0.08), count: targetCount - levels.count)
        return padding + levels
    }
}

// MARK: - Playback Waveform with Scrubber

struct PlaybackWaveformView: View {
    let samples: [CGFloat]
    let progress: Double
    var activeColor: Color = .blue
    var inactiveColor: Color = Color(.systemGray4)
    var barWidth: CGFloat = 2
    var spacing: CGFloat = 1.5
    var onSeek: ((Double) -> Void)?

    var body: some View {
        GeometryReader { geometry in
            let w = geometry.size.width
            let h = geometry.size.height
            let count = max(1, samples.count)
            // Compute bar width so bars fill exactly w
            let totalSpacing = CGFloat(count - 1) * spacing
            let computedBar = max(1, (w - totalSpacing) / CGFloat(count))

            ZStack(alignment: .leading) {
                // Canvas draws all bars at exact positions
                Canvas { ctx, size in
                    for (i, sample) in samples.enumerated() {
                        let x = CGFloat(i) * (computedBar + spacing)
                        let barH = max(3, sample * size.height * 0.85)
                        let rect = CGRect(
                            x: x,
                            y: (size.height - barH) / 2,
                            width: computedBar,
                            height: barH
                        )
                        let barProgress = Double(i) / Double(max(1, count - 1))
                        let color = barProgress <= progress ? activeColor : inactiveColor
                        ctx.fill(
                            Path(roundedRect: rect, cornerRadius: computedBar / 2),
                            with: .color(color)
                        )
                    }
                }
                .frame(width: w, height: h)

                // Playhead line
                Rectangle()
                    .fill(activeColor)
                    .frame(width: 2, height: h + 4)
                    .offset(x: max(0, CGFloat(progress) * w - 1))
                    .shadow(color: activeColor.opacity(0.4), radius: 3)
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        let fraction = max(0, min(1, value.location.x / w))
                        onSeek?(fraction)
                    }
            )
        }
    }
}

